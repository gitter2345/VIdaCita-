package com.example.citasmedicas;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.citasmedicas.db.FirebaseCitaManager;
import com.example.citasmedicas.model.HorarioMedico;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AdminHorariosActivity extends AppCompatActivity {

    private Spinner spEspecialidad, spMedico, spDias, spEstado;
    private EditText etHoraInicio, etHoraFin;
    private TextView tvHorarioActual;
    private FirebaseCitaManager firebaseManager;

    private String userRol;
    private String userEspecialidad;
    private List<String> especialidadesList = new ArrayList<>();
    private List<String> medicosList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        userRol = getIntent().getStringExtra("USER_ROL");
        userEspecialidad = getIntent().getStringExtra("USER_ESPECIALIDAD");

        // Regla de Permisos: Solo Gerente y Jefe de Especialidad pueden acceder
        boolean esGerenteOJefe = "Gerente".equalsIgnoreCase(userRol) || "Jefe de Especialidad".equalsIgnoreCase(userRol);
        if (!esGerenteOJefe) {
            Toast.makeText(this, "Acceso denegado: Solo el Gerente o Jefe de Área pueden configurar horarios de turnos.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_admin_horarios);

        firebaseManager = new FirebaseCitaManager();

        spEspecialidad = findViewById(R.id.spHorarioEspecialidad);
        spMedico = findViewById(R.id.spHorarioMedico);
        spDias = findViewById(R.id.spHorarioDias);
        spEstado = findViewById(R.id.spHorarioEstado);
        etHoraInicio = findViewById(R.id.etHoraInicio);
        etHoraFin = findViewById(R.id.etHoraFin);
        tvHorarioActual = findViewById(R.id.tvHorarioActual);
        Button btnGuardar = findViewById(R.id.btnGuardarHorario);

        configurarSpinnersFijos();
        cargarEspecialidades();

        etHoraInicio.setOnClickListener(v -> mostrarTimePicker(etHoraInicio));
        etHoraFin.setOnClickListener(v -> mostrarTimePicker(etHoraFin));

        spEspecialidad.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!especialidadesList.isEmpty()) {
                    String esp = especialidadesList.get(position);
                    cargarMedicosDeEspecialidad(esp);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spMedico.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!medicosList.isEmpty()) {
                    String med = medicosList.get(position);
                    consultarHorarioActual(med);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnGuardar.setOnClickListener(v -> guardarHorario());
    }

    private void configurarSpinnersFijos() {
        String[] diasOptions = {"Lunes a Viernes", "Lunes, Miércoles y Viernes", "Martes y Jueves", "Sábados y Domingos"};
        ArrayAdapter<String> adapterDias = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, diasOptions);
        adapterDias.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDias.setAdapter(adapterDias);

        String[] estadoOptions = {"Disponible", "En Descanso / Licencia"};
        ArrayAdapter<String> adapterEstado = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, estadoOptions);
        adapterEstado.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spEstado.setAdapter(adapterEstado);
    }

    private void cargarEspecialidades() {
        firebaseManager.getEspecialidades().observe(this, list -> {
            especialidadesList = list;
            ArrayAdapter<String> adapterEsp = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, especialidadesList);
            adapterEsp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spEspecialidad.setAdapter(adapterEsp);

            // Si es Jefe de Especialidad, fijar y deshabilitar el spinner de especialidad en su área asignada
            if ("Jefe de Especialidad".equalsIgnoreCase(userRol) && userEspecialidad != null) {
                seleccionarEnSpinner(spEspecialidad, userEspecialidad);
                spEspecialidad.setEnabled(false);
            }
        });
    }

    private void cargarMedicosDeEspecialidad(String especialidad) {
        firebaseManager.getMedicosPorEspecialidad(especialidad).observe(this, list -> {
            medicosList = list;
            ArrayAdapter<String> adapterMed = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, medicosList);
            adapterMed.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spMedico.setAdapter(adapterMed);
        });
    }

    private void consultarHorarioActual(String nombreMedico) {
        firebaseManager.consultarHorarioMedico(nombreMedico, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    HorarioMedico h = snapshot.getValue(HorarioMedico.class);
                    if (h != null) {
                        tvHorarioActual.setText("📅 Horario Registrado de " + h.nombreMedico + ":\n" +
                                "• Días: " + h.diasAtencion + "\n" +
                                "• Turno: " + h.horaInicio + " - " + h.horaFin + "\n" +
                                "• Estado: " + h.estado);
                        
                        etHoraInicio.setText(h.horaInicio);
                        etHoraFin.setText(h.horaFin);
                        seleccionarEnSpinner(spEstado, h.estado);
                        seleccionarEnSpinner(spDias, h.diasAtencion);
                    }
                } else {
                    tvHorarioActual.setText("El " + nombreMedico + " no tiene un horario específico. Se asume turno libre de consulta.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void seleccionarEnSpinner(Spinner spinner, String valor) {
        if (spinner == null || valor == null) return;
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(valor)) {
                spinner.setSelection(i);
                break;
            }
        }
    }

    private void mostrarTimePicker(EditText editText) {
        Calendar c = Calendar.getInstance();
        new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            String hora = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
            editText.setText(hora);
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
    }

    private void guardarHorario() {
        if (medicosList.isEmpty() || especialidadesList.isEmpty()) {
            Toast.makeText(this, "Seleccione un médico válido", Toast.LENGTH_SHORT).show();
            return;
        }

        String medico = medicosList.get(spMedico.getSelectedItemPosition());
        String especialidad = especialidadesList.get(spEspecialidad.getSelectedItemPosition());
        String dias = spDias.getSelectedItem().toString();
        String inicio = etHoraInicio.getText().toString().trim();
        String fin = etHoraFin.getText().toString().trim();
        String estado = spEstado.getSelectedItem().toString();

        if (inicio.isEmpty() || fin.isEmpty()) {
            Toast.makeText(this, "Complete los horarios de inicio y fin", Toast.LENGTH_SHORT).show();
            return;
        }

        HorarioMedico horario = new HorarioMedico(medico, especialidad, dias, inicio, fin, estado);
        firebaseManager.guardarHorarioMedico(horario);

        Toast.makeText(this, "¡Horario de atención guardado para " + medico + "!", Toast.LENGTH_SHORT).show();
        consultarHorarioActual(medico);
    }
}
