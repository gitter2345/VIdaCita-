package com.example.citasmedicas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;

public class AdminDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        MaterialCardView cardEstrategico = findViewById(R.id.cardEstrategico);
        MaterialCardView cardTactico = findViewById(R.id.cardTactico);
        MaterialCardView cardOperacional = findViewById(R.id.cardOperacional);
        View cardValidarDni = findViewById(R.id.cardValidarDni);
        View btnAddPatient = findViewById(R.id.btnAdminAddPatient);
        View btnAdminHorarios = findViewById(R.id.btnAdminHorarios);
        View btnLogoutAdmin = findViewById(R.id.btnLogoutAdmin);

        String rol = getIntent().getStringExtra("USER_ROL");
        String especialidad = getIntent().getStringExtra("USER_ESPECIALIDAD");

        // Regla de Permisos por Rol:
        // 1. Horarios de Atención: Solo Gerente y Jefe de Especialidad
        boolean esGerenteOJefe = "Gerente".equalsIgnoreCase(rol) || "Jefe de Especialidad".equalsIgnoreCase(rol);
        if (btnAdminHorarios != null) {
            btnAdminHorarios.setVisibility(esGerenteOJefe ? View.VISIBLE : View.GONE);
        }

        // 2. Registro en Padrón y Validación DNI: Solo Recepcionista y Gerente (Oculto para Doctores)
        boolean esRecepcionistaOGerente = "Recepcionista".equalsIgnoreCase(rol) || "Gerente".equalsIgnoreCase(rol);
        if (btnAddPatient != null) {
            btnAddPatient.setVisibility(esRecepcionistaOGerente ? View.VISIBLE : View.GONE);
        }
        if (cardValidarDni != null) {
            cardValidarDni.setVisibility(esRecepcionistaOGerente ? View.VISIBLE : View.GONE);
        }

        if ("Recepcionista".equals(rol)) {
            cardEstrategico.setVisibility(View.GONE);
            cardTactico.setVisibility(View.GONE);
        }

        if ("Jefe de Especialidad".equals(rol) && especialidad != null) {
            TextView tvSubtitulo = findViewById(R.id.tvSubtituloDashboard);
            if (tvSubtitulo != null) {
                tvSubtitulo.setText("Jefatura de Área: " + especialidad);
            }
        }

        if (btnLogoutAdmin != null) {
            btnLogoutAdmin.setOnClickListener(v -> {
                new MaterialAlertDialogBuilder(this)
                        .setTitle("🚪 Cerrar Sesión")
                        .setMessage("¿Deseas salir del Panel Administrativo de VIDACITA?")
                        .setPositiveButton("Sí, Salir", (dialog, which) -> {
                            FirebaseAuth.getInstance().signOut();
                            Toast.makeText(this, "Sesión cerrada correctamente", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(this, RoleSelectionActivity.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(i);
                            finish();
                        })
                        .setNegativeButton("Cancelar", null)
                        .show();
            });
        }

        if (cardValidarDni != null) {
            cardValidarDni.setOnClickListener(v -> {
                Intent i = new Intent(this, AdminValidarDniActivity.class);
                i.putExtra("USER_ROL", rol);
                startActivity(i);
            });
        }

        if (btnAdminHorarios != null) {
            btnAdminHorarios.setOnClickListener(v -> {
                Intent i = new Intent(this, AdminHorariosActivity.class);
                i.putExtra("USER_ROL", rol);
                i.putExtra("USER_ESPECIALIDAD", especialidad);
                startActivity(i);
            });
        }

        cardEstrategico.setOnClickListener(v -> {
            Intent i = new Intent(this, AdminEstrategicoActivity.class);
            i.putExtra("USER_ROL", rol);
            i.putExtra("USER_ESPECIALIDAD", especialidad);
            startActivity(i);
        });

        cardTactico.setOnClickListener(v -> {
            Intent i = new Intent(this, AdminTacticoActivity.class);
            i.putExtra("USER_ROL", rol);
            i.putExtra("USER_ESPECIALIDAD", especialidad);
            startActivity(i);
        });

        cardOperacional.setOnClickListener(v -> {
            Intent i = new Intent(this, AdminOperacionalActivity.class);
            i.putExtra("USER_ROL", rol);
            i.putExtra("USER_ESPECIALIDAD", especialidad);
            startActivity(i);
        });

        btnAddPatient.setOnClickListener(v -> {
            Intent i = new Intent(this, AdminAddPatientActivity.class);
            i.putExtra("USER_ROL", rol);
            startActivity(i);
        });
    }
}
