package com.example.citasmedicas.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class PieChartView extends View {

    public static class PieItem {
        public String label;
        public float value;
        public int color;

        public PieItem(String label, float value, int color) {
            this.label = label;
            this.value = value;
            this.color = color;
        }
    }

    private List<PieItem> pieItems = new ArrayList<>();
    private Paint slicePaint;
    private Paint holePaint;
    private Paint textPaint;
    private Paint legendPaint;
    private RectF boundsF;

    public PieChartView(Context context) {
        super(context);
        init();
    }

    public PieChartView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public PieChartView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        slicePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        slicePaint.setStyle(Paint.Style.FILL);

        holePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        holePaint.setColor(Color.WHITE);
        holePaint.setStyle(Paint.Style.FILL);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.parseColor("#003353"));
        textPaint.setTextSize(30f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);

        legendPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        legendPaint.setColor(Color.parseColor("#475569"));
        legendPaint.setTextSize(26f);

        boundsF = new RectF();
    }

    public void setPieData(List<PieItem> items) {
        this.pieItems = items;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (pieItems == null || pieItems.isEmpty()) return;

        float width = getWidth();
        float height = getHeight();

        float totalValue = 0f;
        for (PieItem item : pieItems) {
            totalValue += item.value;
        }

        if (totalValue <= 0f) return;

        float pieDiameter = Math.min(width * 0.55f, height * 0.75f);
        float centerX = width * 0.35f;
        float centerY = height / 2f;

        boundsF.set(centerX - (pieDiameter / 2f), centerY - (pieDiameter / 2f),
                centerX + (pieDiameter / 2f), centerY + (pieDiameter / 2f));

        float startAngle = -90f;
        for (PieItem item : pieItems) {
            if (item.value <= 0f) continue;
            float sweepAngle = (item.value / totalValue) * 360f;
            slicePaint.setColor(item.color);
            canvas.drawArc(boundsF, startAngle, sweepAngle, true, slicePaint);
            startAngle += sweepAngle;
        }

        // Draw Center Donut Hole
        float holeRadius = pieDiameter * 0.32f;
        canvas.drawCircle(centerX, centerY, holeRadius, holePaint);
        canvas.drawText((int) totalValue + " Citas", centerX, centerY + 10f, textPaint);

        // Draw Legend on Right Side
        float legendX = width * 0.62f;
        float legendY = centerY - (pieItems.size() * 32f / 2f);

        for (PieItem item : pieItems) {
            slicePaint.setColor(item.color);
            canvas.drawCircle(legendX, legendY, 12f, slicePaint);

            int pct = (int) ((item.value / totalValue) * 100f);
            String legendText = item.label + ": " + (int) item.value + " (" + pct + "%)";
            canvas.drawText(legendText, legendX + 24f, legendY + 8f, legendPaint);

            legendY += 40f;
        }
    }
}
