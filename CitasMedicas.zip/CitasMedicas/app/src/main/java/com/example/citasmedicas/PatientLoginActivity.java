package com.example.citasmedicas;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PatientLoginActivity extends AppCompatActivity {

    private EditText etDni, etPassword;
    private Button btnLogin;
    private ProgressBar pb;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);

        mAuth = FirebaseAuth.getInstance();

        etDni = findViewById(R.id.etDniLogin);
        etPassword = findViewById(R.id.etPasswordLogin);
        btnLogin = findViewById(R.id.btnEntrarPaciente);
        pb = findViewById(R.id.pbLoginPaciente);
        TextView tvReg = findViewById(R.id.tvRegistrarse);
        TextView tvForgot = findViewById(R.id.tvForgotPasswordPatient);

        btnLogin.setOnClickListener(v -> realizarLogin());
        tvReg.setOnClickListener(v -> startActivity(new Intent(this, PatientRegisterActivity.class)));
        
        if (tvForgot != null) {
            tvForgot.setOnClickListener(v -> mostrarDialogoRecuperarPassword());
        }
    }

    private void mostrarDialogoRecuperarPassword() {
        final EditText etEmailReset = new EditText(this);
        etEmailReset.setHint("ejemplo@correo.com");
        etEmailReset.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        
        String dni = etDni.getText().toString().trim();
        if (dni.length() == 8) {
            etEmailReset.setText(dni + "@paciente.vidacita.com");
        }

        new MaterialAlertDialogBuilder(this)
                .setTitle("🔑 Recuperar Contraseña")
                .setMessage("Ingresa tu correo registrado para enviarte un enlace seguro de restablecimiento de contraseña.")
                .setView(etEmailReset)
                .setPositiveButton("Enviar Enlace", (dialog, which) -> {
                    String email = etEmailReset.getText().toString().trim();
                    if (email.isEmpty()) {
                        Toast.makeText(this, "Por favor ingrese un correo válido", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    mAuth.sendPasswordResetEmail(email).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(this, "¡Enlace de recuperación enviado a " + email + "! Revisa tu correo o bandeja de spam.", Toast.LENGTH_LONG).show();
                        } else {
                            String err = (task.getException() != null) ? task.getException().getMessage() : "Error al enviar correo";
                            Toast.makeText(this, "Error: " + err, Toast.LENGTH_LONG).show();
                        }
                    });
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void realizarLogin() {
        String dni = etDni.getText().toString().trim();
        String pass = etPassword.getText().toString().trim();

        if (dni.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Complete sus credenciales", Toast.LENGTH_SHORT).show();
            return;
        }

        btnLogin.setEnabled(false);
        pb.setVisibility(View.VISIBLE);

        FirebaseDatabase.getInstance().getReference("pacientes").child(dni)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String email = snapshot.child("email").getValue(String.class);
                    if (email == null || email.isEmpty()) {
                        email = dni + "@paciente.vidacita.com";
                    }

                    mAuth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(PatientLoginActivity.this, "¡Bienvenido a VIDACITA!", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(PatientLoginActivity.this, MainActivity.class);
                            i.putExtra("PATIENT_DNI", dni);
                            startActivity(i);
                            finish();
                        } else {
                            errorLogin("Contraseña o credenciales incorrectas");
                        }
                    });
                } else {
                    errorLogin("El DNI no está registrado");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                errorLogin("Error de servidor");
            }
        });
    }

    private void errorLogin(String msg) {
        btnLogin.setEnabled(true);
        pb.setVisibility(View.GONE);
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
