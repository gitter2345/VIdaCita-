package com.example.citasmedicas;

import android.Manifest;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.citasmedicas.db.FirebaseCitaManager;
import com.example.citasmedicas.model.Cita;
import com.example.citasmedicas.utils.ReminderReceiver;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ProgramarCitaActivity extends AppCompatActivity {

    private EditText etDni, etNombres, etApellidos, etEdad, etFecha, etHora;
    private TextView tvDisponibilidad;
    private Spinner spMedicos, spGenero, spEspecialidad;
    private Button btnGuardar;
    private FirebaseCitaManager firebaseManager;
    private List<String> especialidadesList = new ArrayList<>();
    private List<String> medicosList = new ArrayList<>();
    private String editCitaId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_programar_cita);

        firebaseManager = new FirebaseCitaManager();

        String dniPrellenado = getIntent().getStringExtra("PATIENT_DNI");
        editCitaId = getIntent().getStringExtra("EDIT_CITA_ID");

        etDni = findViewById(R.id.etDniPaciente);
        etNombres = findViewById(R.id.etNombres);
        etApellidos = findViewById(R.id.etApellidos);
        etEdad = findViewById(R.id.etEdad);
        etFecha = findViewById(R.id.etFecha);
        etHora = findViewById(R.id.etHora);
        spMedicos = findViewById(R.id.spMedicos);
        spGenero = findViewById(R.id.spGenero);
        spEspecialidad = findViewById(R.id.spEspecialidad);
        tvDisponibilidad = findViewById(R.id.tvDisponibilidad);
        btnGuardar = findViewById(R.id.btnGuardarCita);

        pedirPermisoNotificacion();
        configurarSpinnerGenero();
        cargarEspecialidadesDesdeFirebase();

        if (dniPrellenado != null && !dniPrellenado.isEmpty()) {
            etDni.setText(dniPrellenado);
            etDni.setEnabled(false);
            cargarPerfilPaciente(dniPrellenado);
        }

        // Listener para autocompletar automáticamente cuando se ingresa un DNI de 8 dígitos
        etDni.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 8) {
                    cargarPerfilPaciente(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        if (editCitaId != null) {
            btnGuardar.setText("Confirmar Reprogramación");
            etFecha.setText(getIntent().getStringExtra("EDIT_CITA_FECHA"));
            etHora.setText(getIntent().getStringExtra("EDIT_CITA_HORA"));
        }

        btnGuardar.setOnClickListener(v -> guardarCita());
        
        etFecha.setOnClickListener(v -> mostrarDatePicker());
        etHora.setOnClickListener(v -> mostrarTimePicker());

        spEspecialidad.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String especialidadSeleccionada = parent.getItemAtPosition(position).toString();
                cargarMedicosDeEspecialidad(especialidadSeleccionada);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void pedirPermisoNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
    }

    private void cargarEspecialidadesDesdeFirebase() {
        firebaseManager.getEspecialidades().observe(this, list -> {
            especialidadesList = list;
            ArrayAdapter<String> adapterEsp = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, especialidadesList);
            adapterEsp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spEspecialidad.setAdapter(adapterEsp);
        });
    }

    private void cargarMedicosDeEspecialidad(String especialidad) {
        firebaseManager.getMedicosPorEspecialidad(especialidad).observe(this, list -> {
            medicosList = list;
            ArrayAdapter<String> adapterMed = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, medicosList);
            adapterMed.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spMedicos.setAdapter(adapterMed);
            verificarHorariosLibres();
        });
    }

    private void verificarHorariosLibres() {
        if (medicosList.isEmpty() || spMedicos == null || spMedicos.getSelectedItemPosition() < 0) return;
        
        String doctor = medicosList.get(spMedicos.getSelectedItemPosition());
        String fecha = etFecha.getText().toString().trim();

        firebaseManager.consultarHorarioMedico(doctor, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    com.example.citasmedicas.model.HorarioMedico h = snapshot.getValue(com.example.citasmedicas.model.HorarioMedico.class);
                    if (h != null) {
                        if ("En Descanso / Licencia".equalsIgnoreCase(h.estado)) {
                            tvDisponibilidad.setText("⚠️ El " + doctor + " se encuentra en descanso o licencia médica.");
                            tvDisponibilidad.setTextColor(ContextCompat.getColor(ProgramarCitaActivity.this, android.R.color.holo_red_dark));
                            return;
                        } else if (h.diasAtencion != null && h.horaInicio != null && h.horaFin != null) {
                            tvDisponibilidad.setText("📅 Turno de " + doctor + ": " + h.diasAtencion + " (" + h.horaInicio + " - " + h.horaFin + ")");
                            tvDisponibilidad.setTextColor(ContextCompat.getColor(ProgramarCitaActivity.this, android.R.color.holo_green_dark));
                        }
                    }
                }
                comprobarCitasOcupadas(doctor, fecha);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                comprobarCitasOcupadas(doctor, fecha);
            }
        });
    }

    private void comprobarCitasOcupadas(String doctor, String fecha) {
        if (fecha.isEmpty()) return;
        
        FirebaseDatabase.getInstance().getReference("citas")
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    List<String> ocupados = new ArrayList<>();
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        Cita c = postSnapshot.getValue(Cita.class);
                        if (c != null && c.nombreMedico != null && c.nombreMedico.equals(doctor) && c.fecha != null && c.fecha.equals(fecha) && !"Cancelada".equals(c.estado)) {
                            ocupados.add(c.hora);
                        }
                    }
                    if (!ocupados.isEmpty()) {
                        tvDisponibilidad.append("\n⚠️ Horarios OCUPADOS el " + fecha + ": " + ocupados.toString());
                    }
                }
                @Override public void onCancelled(@NonNull DatabaseError error) {}
            });
    }

    private void bloquearCampoTexto(EditText editText, String texto) {
        if (editText != null) {
            if (texto != null) {
                editText.setText(texto);
            }
            editText.setFocusable(false);
            editText.setFocusableInTouchMode(false);
            editText.setClickable(false);
            editText.setTextColor(android.graphics.Color.parseColor("#0F172A"));
        }
    }

    private void cargarPerfilPaciente(String dni) {
        FirebaseDatabase.getInstance().getReference("pacientes").child(dni)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String nombres = snapshot.child("nombres").getValue(String.class);
                    String apellidos = snapshot.child("apellidos").getValue(String.class);
                    String fechaNac = snapshot.child("fechaNacimiento").getValue(String.class);
                    Object edadObj = snapshot.child("edad").getValue();
                    String genero = snapshot.child("genero").getValue(String.class);
                    
                    int edadCalculada = (fechaNac != null && !fechaNac.isEmpty()) 
                            ? com.example.citasmedicas.utils.DniValidator.calcularEdad(fechaNac) 
                            : ((edadObj != null) ? Integer.parseInt(String.valueOf(edadObj)) : 0);

                    if (nombres != null || apellidos != null) {
                        String unificado = ((nombres != null ? nombres : "") + " " + (apellidos != null ? apellidos : "")).trim();
                        String[] partes = com.example.citasmedicas.utils.DniValidator.separarNombresYApellidos(unificado);
                        bloquearCampoTexto(etNombres, partes[0]);
                        bloquearCampoTexto(etApellidos, partes[1]);
                    }
                    if (edadCalculada > 0) {
                        bloquearCampoTexto(etEdad, String.valueOf(edadCalculada));
                    }
                    if (genero != null) {
                        seleccionarGeneroEnSpinner(genero);
                    }
                } else {
                    consultarPadronYCitasAnteriores(dni);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void consultarPadronYCitasAnteriores(String dni) {
        // 1. Consultar padrón oficial de la clínica
        firebaseManager.consultarPadron(dni, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String nombreCompleto = snapshot.getValue(String.class);
                    if (nombreCompleto != null) {
                        String[] partes = com.example.citasmedicas.utils.DniValidator.separarNombresYApellidos(nombreCompleto);
                        bloquearCampoTexto(etNombres, partes[0]);
                        bloquearCampoTexto(etApellidos, partes[1]);
                    } else {
                        etNombres.setText("");
                        etApellidos.setText("");
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

        // 2. Buscar en citas previas para extraer edad y género si existen
        FirebaseDatabase.getInstance().getReference("citas")
                .orderByChild("dniPaciente").equalTo(dni)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Cita c = postSnapshot.getValue(Cita.class);
                    if (c != null) {
                        if (c.edad > 0) {
                            bloquearCampoTexto(etEdad, String.valueOf(c.edad));
                        }
                        if (c.genero != null) {
                            seleccionarGeneroEnSpinner(c.genero);
                        }
                        break;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void seleccionarGeneroEnSpinner(String genero) {
        for (int i = 0; i < spGenero.getCount(); i++) {
            if (spGenero.getItemAtPosition(i).toString().equalsIgnoreCase(genero)) {
                spGenero.setSelection(i);
                break;
            }
        }
    }

    private void mostrarDatePicker() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            String fecha = String.format(Locale.getDefault(), "%02d/%02d/%d", dayOfMonth, month + 1, year);
            etFecha.setText(fecha);
            verificarHorariosLibres();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void mostrarTimePicker() {
        Calendar c = Calendar.getInstance();
        new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            String hora = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
            etHora.setText(hora);
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
    }

    private void configurarSpinnerGenero() {
        String[] generos = {"Masculino", "Femenino", "Otro"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, generos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spGenero.setAdapter(adapter);
    }

    private void guardarCita() {
        String dni = etDni.getText().toString().trim();
        String nombres = etNombres.getText().toString().trim();
        String apellidos = etApellidos.getText().toString().trim();
        String edadStr = etEdad.getText().toString().trim();
        String fecha = etFecha.getText().toString().trim();
        String hora = etHora.getText().toString().trim();
        String genero = spGenero.getSelectedItem().toString();

        if (dni.isEmpty() || nombres.isEmpty() || apellidos.isEmpty() || 
            edadStr.isEmpty() || fecha.isEmpty() || hora.isEmpty() || medicosList.isEmpty()) {
            Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        int edad = Integer.parseInt(edadStr);
        String medicoSeleccionado = medicosList.get(spMedicos.getSelectedItemPosition());
        String especialidadSeleccionada = spEspecialidad.getSelectedItem().toString();
        
        // Guardar/Actualizar la edad y género del paciente en su perfil de Firebase para futuras consultas
        FirebaseDatabase.getInstance().getReference("pacientes").child(dni).child("edad").setValue(edad);
        FirebaseDatabase.getInstance().getReference("pacientes").child(dni).child("genero").setValue(genero);

        btnGuardar.setEnabled(false);
        firebaseManager.verificarDisponibilidad(medicoSeleccionado, fecha, hora, isAvailable -> {
            if (isAvailable) {
                String nuevoEstado = (editCitaId != null) ? "Pendiente de Aprobación" : "Programada";
                Cita cita = new Cita(dni, nombres, apellidos, genero, edad, 
                                         medicoSeleccionado, especialidadSeleccionada, fecha, hora);
                cita.estado = nuevoEstado;

                if (editCitaId != null) {
                    cita.id = editCitaId;
                    firebaseManager.actualizarCita(cita);
                    programarRecordatorios(cita);
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Cita enviada para aprobación del doctor", Toast.LENGTH_LONG).show();
                        finish();
                    });
                } else {
                    firebaseManager.registrarCita(cita);
                    programarRecordatorios(cita);
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Cita programada con éxito", Toast.LENGTH_SHORT).show();
                        finish();
                    });
                }
            } else {
                runOnUiThread(() -> {
                    btnGuardar.setEnabled(true);
                    Toast.makeText(this, "HORARIO OCUPADO: El doctor ya tiene una cita a esa hora.", Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void programarRecordatorios(Cita cita) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
            Date fechaCita = sdf.parse(cita.fecha + " " + cita.hora);
            if (fechaCita == null) return;

            long tiempoCita = fechaCita.getTime();
            
            // 24 horas antes
            programarAlarma(tiempoCita - (24 * 60 * 60 * 1000), 
                    "Recordatorio de Cita (Mañana)", 
                    "Hola " + cita.nombres + ", mañana tienes tu cita de " + cita.especialidad + " a las " + cita.hora,
                    1);

            // 1 hora antes
            programarAlarma(tiempoCita - (60 * 60 * 1000), 
                    "Tu cita es pronto", 
                    "En 1 hora comienza tu cita con " + cita.nombreMedico,
                    2);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void programarAlarma(long tiempoMilis, String titulo, String mensaje, int id) {
        if (tiempoMilis <= System.currentTimeMillis()) return;

        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("titulo", titulo);
        intent.putExtra("mensaje", mensaje);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, (int)(System.currentTimeMillis() + id), 
                intent, PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, tiempoMilis, pendingIntent);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, tiempoMilis, pendingIntent);
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, tiempoMilis, pendingIntent);
            }
        }
    }
}
