package com.example.citasmedicas.model;

public class ReniecResultado {
    public String dni;
    public String nombres;
    public String apellidoPaterno;
    public String apellidoMaterno;
    public boolean exito;
    public String fuente; // "API RENIEC Web" o "Padrón Oficial RENIEC"

    public ReniecResultado() {
    }

    public ReniecResultado(String dni, String nombres, String apellidoPaterno, String apellidoMaterno, boolean exito, String fuente) {
        this.dni = dni;
        this.nombres = nombres;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.exito = exito;
        this.fuente = fuente;
    }

    public String getApellidos() {
        String pat = (apellidoPaterno != null) ? apellidoPaterno : "";
        String mat = (apellidoMaterno != null) ? apellidoMaterno : "";
        return (pat + " " + mat).trim();
    }

    public String getNombreCompleto() {
        String nom = (nombres != null) ? nombres : "";
        return (nom + " " + getApellidos()).trim();
    }
}
