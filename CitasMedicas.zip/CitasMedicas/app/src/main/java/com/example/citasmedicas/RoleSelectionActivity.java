package com.example.citasmedicas;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;
import com.example.citasmedicas.model.Cita;
import com.example.citasmedicas.model.Usuario;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RoleSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(
                androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO
        );
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_role_selection);

        // --- INICIALIZACIÓN DE DATOS EN LA NUBE ---
        inicializarClinicaFirebase();
        // ------------------------------------------

        MaterialCardView cardPaciente = findViewById(R.id.cardPaciente);
        MaterialCardView cardAdmin = findViewById(R.id.cardAdmin);

        cardPaciente.setOnClickListener(v -> {
            startActivity(new Intent(RoleSelectionActivity.this, PatientLoginActivity.class));
        });

        cardAdmin.setOnClickListener(v -> {
            startActivity(new Intent(RoleSelectionActivity.this, LoginActivity.class));
        });
    }

    private void inicializarClinicaFirebase() {
        try {
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
            FirebaseAuth auth = FirebaseAuth.getInstance();
            
            // 1. Usuarios Centrales
            ref.child("usuarios").child("manuel").setValue(new Usuario("manuel", "manuel@vidacita.com", "Gerente"));
            ref.child("usuarios").child("recepcion1").setValue(new Usuario("recepcion1", "recepcion1@vidacita.com", "Recepcionista"));
            
            asegurarCuentaAuth(auth, "manuel@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "recepcion1@vidacita.com", "123456");

            // 2. CARPETA DE DOCTORES (Todos los 12 Médicos de la Clínica)
            DatabaseReference docRef = ref.child("usuarios").child("doctores");
            docRef.child("ramirez").setValue(new Usuario("ramirez", "ramirez@vidacita.com", "Doctor"));
            docRef.child("castro").setValue(new Usuario("castro", "castro@vidacita.com", "Doctor"));
            docRef.child("perez").setValue(new Usuario("perez", "perez@vidacita.com", "Doctor"));
            docRef.child("garcia").setValue(new Usuario("garcia", "garcia@vidacita.com", "Doctor"));
            docRef.child("mendoza").setValue(new Usuario("mendoza", "mendoza@vidacita.com", "Doctor"));
            docRef.child("sanchez").setValue(new Usuario("sanchez", "sanchez@vidacita.com", "Doctor"));
            docRef.child("lujan").setValue(new Usuario("lujan", "lujan@vidacita.com", "Doctor"));
            docRef.child("soto").setValue(new Usuario("soto", "soto@vidacita.com", "Doctor"));
            docRef.child("torres").setValue(new Usuario("torres", "torres@vidacita.com", "Doctor"));
            docRef.child("vargas").setValue(new Usuario("vargas", "vargas@vidacita.com", "Doctor"));
            docRef.child("luna").setValue(new Usuario("luna", "luna@vidacita.com", "Doctor"));
            docRef.child("rios").setValue(new Usuario("rios", "rios@vidacita.com", "Doctor"));
            
            asegurarCuentaAuth(auth, "ramirez@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "castro@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "perez@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "garcia@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "mendoza@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "sanchez@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "lujan@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "soto@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "torres@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "vargas@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "luna@vidacita.com", "123456");
            asegurarCuentaAuth(auth, "rios@vidacita.com", "123456");

            // 3. Padrón Oficial de Pacientes
            ref.child("padron_oficial").child("74724080").setValue("Manuel Ronaldo Lopez Rodriguez");
            ref.child("padron_oficial").child("12345678").setValue("Ana Maria Garcia Morales");
            ref.child("padron_oficial").child("87654321").setValue("Carlos Alberto Mendoza Ramos");
            ref.child("padron_oficial").child("45678912").setValue("Lucia Fernanda Torres Vargas");
            ref.child("padron_oficial").child("78912345").setValue("Roberto Carlos Quispe Huaman");
            ref.child("padron_oficial").child("23456789").setValue("Elena Sofia Ramirez Castro");

            // 4. Perfiles de Pacientes para Login y Autocompletado
            registrarPacienteDemo(ref, "74724080", "123456", "Manuel Ronaldo", "Lopez Rodriguez", 25, "Masculino");
            registrarPacienteDemo(ref, "12345678", "123456", "Ana Maria", "Garcia Morales", 32, "Femenino");
            registrarPacienteDemo(ref, "87654321", "123456", "Carlos Alberto", "Mendoza Ramos", 45, "Masculino");
            registrarPacienteDemo(ref, "45678912", "123456", "Lucia Fernanda", "Torres Vargas", 8, "Femenino");
            registrarPacienteDemo(ref, "78912345", "123456", "Roberto Carlos", "Quispe Huaman", 5, "Masculino");
            registrarPacienteDemo(ref, "23456789", "123456", "Elena Sofia", "Ramirez Castro", 58, "Femenino");

            // 5. Especialidades
            Map<String, List<String>> clinica = new HashMap<>();
            clinica.put("Medicina General", Arrays.asList("Dr. Ramírez", "Dr. Castro"));
            clinica.put("Odontología", Arrays.asList("Dra. Mendoza", "Dr. Ríos"));
            clinica.put("Pediatría", Arrays.asList("Dra. García", "Dra. Luna"));
            clinica.put("Cardiología", Arrays.asList("Dr. Pérez", "Dr. Vargas"));
            clinica.put("Dermatología", Arrays.asList("Dr. Luján", "Dra. Soto"));
            clinica.put("Oftalmología", Arrays.asList("Dr. Sánchez"));
            clinica.put("Ginecología", Arrays.asList("Dra. Torres"));
            clinica.put("Traumatología", Arrays.asList("Dr. Vargas"));
            clinica.put("Psicología", Arrays.asList("Dra. Luna"));
            clinica.put("Nutrición", Arrays.asList("Lic. Ríos"));

            ref.child("especialidades").setValue(clinica);

            // 6. Citas Demo
            ref.child("citas").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (!snapshot.exists() || snapshot.getChildrenCount() < 3) {
                        crearCitaDemo(ref, "74724080", "Manuel Ronaldo", "Lopez Rodriguez", "Masculino", 25, "Dr. Ramírez", "Medicina General", "28/11/2024", "09:00", "Programada");
                        crearCitaDemo(ref, "12345678", "Ana Maria", "Garcia Morales", "Femenino", 32, "Dr. Castro", "Medicina General", "28/11/2024", "10:30", "Pendiente de Aprobación");
                        crearCitaDemo(ref, "87654321", "Carlos Alberto", "Mendoza Ramos", "Masculino", 45, "Dr. Ramírez", "Medicina General", "29/11/2024", "11:00", "Cancelada");
                        
                        crearCitaDemo(ref, "45678912", "Lucia Fernanda", "Torres Vargas", "Femenino", 8, "Dra. García", "Pediatría", "28/11/2024", "15:00", "Programada");
                        crearCitaDemo(ref, "78912345", "Roberto Carlos", "Quispe Huaman", "Masculino", 5, "Dra. Luna", "Pediatría", "30/11/2024", "16:30", "Pendiente de Aprobación");
                        
                        crearCitaDemo(ref, "23456789", "Elena Sofia", "Ramirez Castro", "Femenino", 58, "Dr. Pérez", "Cardiología", "29/11/2024", "08:30", "Programada");
                        crearCitaDemo(ref, "12345678", "Ana Maria", "Garcia Morales", "Femenino", 32, "Dr. Vargas", "Cardiología", "01/12/2024", "14:00", "Programada");
                        
                        crearCitaDemo(ref, "87654321", "Carlos Alberto", "Mendoza Ramos", "Masculino", 45, "Dra. Mendoza", "Odontología", "30/11/2024", "10:00", "Programada");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {}
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void asegurarCuentaAuth(FirebaseAuth auth, String email, String password) {
        if (auth == null || email == null || password == null || password.length() < 6) return;
        try {
            auth.createUserWithEmailAndPassword(email, password);
        } catch (Exception ignored) {}
    }

    private void registrarPacienteDemo(DatabaseReference ref, String dni, String pass, String nombres, String apellidos, int edad, String genero) {
        DatabaseReference pRef = ref.child("pacientes").child(dni);
        String email = dni + "@paciente.vidacita.com";
        pRef.child("username").setValue(dni);
        pRef.child("email").setValue(email);
        pRef.child("nombres").setValue(nombres);
        pRef.child("apellidos").setValue(apellidos);
        pRef.child("edad").setValue(edad);
        pRef.child("genero").setValue(genero);
        pRef.child("rol").setValue("Paciente");

        asegurarCuentaAuth(FirebaseAuth.getInstance(), email, pass);
    }

    private void crearCitaDemo(DatabaseReference ref, String dni, String nombres, String apellidos, 
                              String genero, int edad, String medico, String especialidad, 
                              String fecha, String hora, String estado) {
        String key = ref.child("citas").push().getKey();
        if (key != null) {
            Cita c = new Cita(dni, nombres, apellidos, genero, edad, medico, especialidad, fecha, hora);
            c.id = key;
            c.estado = estado;
            ref.child("citas").child(key).setValue(c);
        }
    }
}
