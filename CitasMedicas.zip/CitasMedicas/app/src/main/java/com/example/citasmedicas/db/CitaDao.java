package com.example.citasmedicas.db;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.citasmedicas.model.Cita;
import com.example.citasmedicas.model.Medico;
import com.example.citasmedicas.model.ReporteEspecialidad;

import java.util.List;

@Dao
public interface CitaDao {
    @Insert
    void insertCita(Cita cita);

    @Query("SELECT * FROM citas WHERE dniPaciente = :dni ORDER BY fecha DESC")
    LiveData<List<Cita>> getCitasByDni(String dni);

    @Query("SELECT * FROM citas ORDER BY fecha DESC, hora DESC")
    LiveData<List<Cita>> getAllCitas();

    @Update
    void updateCita(Cita cita);

    @Insert
    void insertMedico(Medico medico);

    @Query("SELECT * FROM medicos")
    List<Medico> getAllMedicos();

    @Query("SELECT especialidad, COUNT(*) as totalCitas FROM citas GROUP BY especialidad")
    LiveData<List<ReporteEspecialidad>> getReporteEspecialidades();

    @Query("SELECT COUNT(*) FROM citas")
    LiveData<Integer> getTotalCitasCount();

    @Query("SELECT COUNT(*) FROM citas WHERE estado = 'Cancelada'")
    LiveData<Integer> getCanceladasCount();
}
