package com.example.citasmedicas.adapter;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.citasmedicas.R;
import com.example.citasmedicas.model.Cita;

import java.util.ArrayList;
import java.util.List;

public class CitaAdapter extends RecyclerView.Adapter<CitaAdapter.CitaViewHolder> {

    private List<Cita> citas = new ArrayList<>();
    private OnCitaClickListener listener;
    private String userRole = "Paciente";

    public interface OnCitaClickListener {
        void onCancelClick(Cita cita);
        void onReprogramClick(Cita cita);
        void onAcceptClick(Cita cita);
        void onRejectClick(Cita cita);
    }

    public void setOnCitaClickListener(OnCitaClickListener listener) {
        this.listener = listener;
    }

    public void setUserRole(String role) {
        this.userRole = role;
    }

    public void setCitas(List<Cita> citas) {
        this.citas = citas;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CitaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cita, parent, false);
        return new CitaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CitaViewHolder holder, int position) {
        Cita current = citas.get(position);
        
        String nombreCompleto = current.nombres + " " + current.apellidos;
        holder.tvNombrePaciente.setText(nombreCompleto + " (" + current.edad + " años)");
        
        holder.tvEspecialidad.setText(current.especialidad);
        holder.tvMedico.setText("Dr. " + current.nombreMedico.replace("Dr. ", "").replace("Dra. ", ""));
        holder.tvFechaHora.setText(current.fecha + " • " + current.hora);
        holder.tvEstado.setText(current.estado);

        if ("Cancelada".equals(current.estado)) {
            holder.tvEstado.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FEE2E2")));
            holder.tvEstado.setTextColor(Color.parseColor("#B91C1C"));
        } else if ("Pendiente de Aprobación".equals(current.estado)) {
            holder.tvEstado.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FEF3C7")));
            holder.tvEstado.setTextColor(Color.parseColor("#B45309"));
        } else {
            holder.tvEstado.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#DCFCE7")));
            holder.tvEstado.setTextColor(Color.parseColor("#15803D"));
        }

        // Lógica de visibilidad de botones por Rol de Usuario
        boolean esPaciente = "Paciente".equalsIgnoreCase(userRole);
        boolean esRecepcionista = "Recepcionista".equalsIgnoreCase(userRole);
        boolean esMedicoOGerente = "Doctor".equalsIgnoreCase(userRole) 
                || "Jefe de Especialidad".equalsIgnoreCase(userRole) 
                || "Gerente".equalsIgnoreCase(userRole);

        if ("Cancelada".equals(current.estado) || esRecepcionista) {
            // Recepcionistas solo LECTURA de citas (los botones se ocultan por completo)
            holder.btnCancelar.setVisibility(View.GONE);
            holder.btnReprogramar.setVisibility(View.GONE);
            holder.btnAceptar.setVisibility(View.GONE);
            holder.btnRechazar.setVisibility(View.GONE);
        } else {
            // El paciente puede cancelar y reprogramar sus propias citas
            holder.btnCancelar.setVisibility(esPaciente ? View.VISIBLE : View.GONE);
            holder.btnReprogramar.setVisibility(esPaciente ? View.VISIBLE : View.GONE);

            // Solo Médicos, Jefes de Área y Gerente pueden aceptar o rechazar si está pendiente de aprobación
            if ("Pendiente de Aprobación".equals(current.estado) && esMedicoOGerente) {
                holder.btnAceptar.setVisibility(View.VISIBLE);
                holder.btnRechazar.setVisibility(View.VISIBLE);
            } else {
                holder.btnAceptar.setVisibility(View.GONE);
                holder.btnRechazar.setVisibility(View.GONE);
            }
        }

        holder.btnCancelar.setOnClickListener(v -> {
            if (listener != null) {
                listener.onCancelClick(current);
            }
        });

        holder.btnReprogramar.setOnClickListener(v -> {
            if (listener != null) {
                listener.onReprogramClick(current);
            }
        });

        holder.btnAceptar.setOnClickListener(v -> {
            if (listener != null) {
                listener.onAcceptClick(current);
            }
        });

        holder.btnRechazar.setOnClickListener(v -> {
            if (listener != null) {
                listener.onRejectClick(current);
            }
        });
    }

    @Override
    public int getItemCount() {
        return citas.size();
    }

    static class CitaViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombrePaciente, tvEspecialidad, tvMedico, tvFechaHora, tvEstado;
        Button btnCancelar, btnReprogramar, btnAceptar, btnRechazar;

        public CitaViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombrePaciente = itemView.findViewById(R.id.tvNombrePaciente);
            tvEspecialidad = itemView.findViewById(R.id.tvEspecialidad);
            tvMedico = itemView.findViewById(R.id.tvMedico);
            tvFechaHora = itemView.findViewById(R.id.tvFechaHora);
            tvEstado = itemView.findViewById(R.id.tvEstado);
            btnCancelar = itemView.findViewById(R.id.btnCancelarCita);
            btnReprogramar = itemView.findViewById(R.id.btnReprogramarCita);
            btnAceptar = itemView.findViewById(R.id.btnAceptarCita);
            btnRechazar = itemView.findViewById(R.id.btnRechazarCita);
        }
    }
}
