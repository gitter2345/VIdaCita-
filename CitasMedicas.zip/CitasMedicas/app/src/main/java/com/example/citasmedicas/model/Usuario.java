package com.example.citasmedicas.model;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Usuario {
    public String username;
    public String email;
    public String rol;
    public String especialidad; // Campo para rol "Jefe de Especialidad" (ej. "Medicina General")

    @Exclude
    public String password; // Excluido de Firebase Realtime Database por seguridad

    public Usuario() {
        // Requerido por Firebase
    }

    public Usuario(String username, String email, String rol, String especialidad) {
        this.username = username;
        this.email = email;
        this.rol = rol;
        this.especialidad = especialidad;
    }

    public Usuario(String username, String email, String rol, String especialidad, String password) {
        this.username = username;
        this.email = email;
        this.rol = rol;
        this.especialidad = especialidad;
        this.password = password;
    }

    public Usuario(String username, String email, String rol) {
        this.username = username;
        this.email = email;
        this.rol = rol;
    }
}
