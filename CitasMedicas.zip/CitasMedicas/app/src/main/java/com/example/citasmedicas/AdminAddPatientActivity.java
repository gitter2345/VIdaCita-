package com.example.citasmedicas;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.citasmedicas.db.FirebaseCitaManager;
import com.example.citasmedicas.model.ReniecResultado;
import com.example.citasmedicas.utils.ReniecApiService;

public class AdminAddPatientActivity extends AppCompatActivity {

    private EditText etDni, etNombre;
    private FirebaseCitaManager firebaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String rol = getIntent().getStringExtra("USER_ROL");
        if ("Doctor".equalsIgnoreCase(rol) || "Jefe de Especialidad".equalsIgnoreCase(rol)) {
            Toast.makeText(this, "Acceso denegado: El registro en padrón es gestionado únicamente por Recepción.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_admin_add_patient);

        firebaseManager = new FirebaseCitaManager();
        etDni = findViewById(R.id.etAdminDni);
        etNombre = findViewById(R.id.etAdminNombre);
        Button btnAutorizar = findViewById(R.id.btnAdminAutorizar);

        // Autocompletar automáticamente el Nombre Completo oficial desde RENIEC al escribir 8 dígitos
        etDni.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 8) {
                    consultarNombreReniec(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnAutorizar.setOnClickListener(v -> {
            String dni = etDni.getText().toString().trim();
            String nombre = etNombre.getText().toString().trim();

            if (dni.length() != 8 || nombre.isEmpty()) {
                Toast.makeText(this, "Ingrese DNI de 8 dígitos y nombre completo", Toast.LENGTH_SHORT).show();
                return;
            }

            firebaseManager.registrarEnPadron(dni, nombre);
            Toast.makeText(this, "¡Paciente " + nombre + " autorizado e incluido en padrón con éxito!", Toast.LENGTH_LONG).show();
            finish();
        });
    }

    private void consultarNombreReniec(String dni) {
        ReniecApiService.consultarDniReniec(dni, new ReniecApiService.ReniecCallback() {
            @Override
            public void onSuccess(ReniecResultado resultado) {
                if (resultado != null && resultado.exito && resultado.getNombreCompleto() != null) {
                    etNombre.setText(resultado.getNombreCompleto());
                    Toast.makeText(AdminAddPatientActivity.this, "Nombre obtenido de RENIEC: " + resultado.getNombreCompleto(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(String mensajeError) {}
        });
    }
}
