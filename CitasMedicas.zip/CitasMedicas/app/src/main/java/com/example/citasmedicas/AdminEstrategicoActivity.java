package com.example.citasmedicas;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;

import com.example.citasmedicas.db.FirebaseCitaManager;
import com.example.citasmedicas.utils.PieChartView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AdminEstrategicoActivity extends AppCompatActivity {

    private TextView tvTotalCitas, tvCanceladas, tvTasa, tvNota;
    private PieChartView pieChartEstados;
    private FirebaseCitaManager firebaseManager;
    private String userEspecialidad;
    private int total = 0;
    private int canceladas = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_estrategico);

        firebaseManager = new FirebaseCitaManager();
        userEspecialidad = getIntent().getStringExtra("USER_ESPECIALIDAD");

        tvTotalCitas = findViewById(R.id.tvTotalCitasGlobal);
        tvCanceladas = findViewById(R.id.tvTotalCanceladas);
        tvTasa = findViewById(R.id.tvTasaCancelacion);
        tvNota = findViewById(R.id.tvNotaGerencial);
        pieChartEstados = findViewById(R.id.pieChartEstados);

        cargarKPIs();
    }

    private void cargarKPIs() {
        LiveData<Map<String, Integer>> kpiSource = firebaseManager.getKPIsDetallados(userEspecialidad);

        kpiSource.observe(this, kpis -> {
            total = kpis.getOrDefault("total", 0);
            canceladas = kpis.getOrDefault("canceladas", 0);
            int programadas = kpis.getOrDefault("programadas", 0);
            int pendientes = kpis.getOrDefault("pendientes", 0);

            tvTotalCitas.setText(String.valueOf(total));
            tvCanceladas.setText(String.valueOf(canceladas));
            actualizarTasa();

            // Cargar datos en el gráfico de Donut / Pastel
            if (pieChartEstados != null) {
                List<PieChartView.PieItem> pieItems = new ArrayList<>();
                if (programadas > 0) {
                    pieItems.add(new PieChartView.PieItem("Programadas", programadas, Color.parseColor("#15803D")));
                }
                if (pendientes > 0) {
                    pieItems.add(new PieChartView.PieItem("Pendientes", pendientes, Color.parseColor("#B45309")));
                }
                if (canceladas > 0) {
                    pieItems.add(new PieChartView.PieItem("Canceladas", canceladas, Color.parseColor("#B91C1C")));
                }
                pieChartEstados.setPieData(pieItems);
            }
        });
    }

    private void actualizarTasa() {
        if (total > 0) {
            double tasa = (canceladas * 100.0) / total;
            tvTasa.setText(String.format(Locale.getDefault(), "%.1f%%", tasa));

            String prefix = (userEspecialidad != null && !userEspecialidad.isEmpty()) 
                    ? "[" + userEspecialidad + "] " : "";

            if (tasa > 20) {
                tvNota.setText(prefix + "ALERTA: La tasa de cancelación es alta. Se recomienda revisar la disponibilidad de los médicos.");
                tvNota.setTextColor(androidx.core.content.ContextCompat.getColor(this, android.R.color.holo_red_dark));
            } else {
                tvNota.setText(prefix + "ESTADO ÓPTIMO: El flujo de citas se mantiene estable.");
                tvNota.setTextColor(androidx.core.content.ContextCompat.getColor(this, android.R.color.black));
            }
        } else {
            tvTasa.setText("0%");
        }
    }
}
