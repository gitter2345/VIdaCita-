package com.example.citasmedicas;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.citasmedicas.model.ReniecResultado;
import com.example.citasmedicas.utils.ReniecApiService;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminValidarDniActivity extends AppCompatActivity {

    private EditText etDni;
    private View cardResultado, bannerVerde, bannerRojo, layoutDatos;
    private TextView tvDniNumero, tvNombres, tvApellidos, tvCuentaEstado, tvMensajeSinRegistro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_validar_dni);

        etDni = findViewById(R.id.etValidarDni);
        Button btnConsultar = findViewById(R.id.btnConsultarDni);
        cardResultado = findViewById(R.id.cardResultadoValidacion);
        bannerVerde = findViewById(R.id.bannerLuzVerde);
        bannerRojo = findViewById(R.id.bannerLuzRoja);
        layoutDatos = findViewById(R.id.layoutDatosPaciente);
        tvDniNumero = findViewById(R.id.tvDniNumero);
        tvNombres = findViewById(R.id.tvNombres);
        tvApellidos = findViewById(R.id.tvApellidos);
        tvCuentaEstado = findViewById(R.id.tvCuentaEstado);
        tvMensajeSinRegistro = findViewById(R.id.tvMensajeSinRegistro);

        btnConsultar.setOnClickListener(v -> validarDniReniec());

        etDni.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 8) {
                    validarDniReniec();
                } else {
                    if (cardResultado != null) cardResultado.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void validarDniReniec() {
        String dni = etDni.getText().toString().trim();
        if (dni.length() != 8) {
            Toast.makeText(this, "Ingrese un DNI de 8 dígitos", Toast.LENGTH_SHORT).show();
            return;
        }

        ReniecApiService.consultarDniReniec(dni, new ReniecApiService.ReniecCallback() {
            @Override
            public void onSuccess(ReniecResultado resultado) {
                if (cardResultado != null) cardResultado.setVisibility(View.VISIBLE);

                if (resultado != null && resultado.exito) {
                    // LUZ VERDE 🟢
                    if (bannerVerde != null) bannerVerde.setVisibility(View.VISIBLE);
                    if (bannerRojo != null) bannerRojo.setVisibility(View.GONE);
                    if (layoutDatos != null) layoutDatos.setVisibility(View.VISIBLE);
                    if (tvMensajeSinRegistro != null) tvMensajeSinRegistro.setVisibility(View.GONE);

                    tvDniNumero.setText("• DNI Registrado: " + resultado.dni);
                    tvNombres.setText("• Nombres: " + resultado.nombres);
                    tvApellidos.setText("• Apellidos: " + resultado.getApellidos());

                    verificarCuentaApp(resultado.dni);
                } else {
                    mostrarLuzRoja(dni);
                }
            }

            @Override
            public void onError(String mensajeError) {
                if (cardResultado != null) cardResultado.setVisibility(View.VISIBLE);
                mostrarLuzRoja(dni);
            }
        });
    }

    private void mostrarLuzRoja(String dni) {
        // LUZ ROJA 🔴
        if (bannerRojo != null) bannerRojo.setVisibility(View.VISIBLE);
        if (bannerVerde != null) bannerVerde.setVisibility(View.GONE);
        if (layoutDatos != null) layoutDatos.setVisibility(View.GONE);
        if (tvMensajeSinRegistro != null) {
            tvMensajeSinRegistro.setVisibility(View.VISIBLE);
            tvMensajeSinRegistro.setText("🔴 El DNI " + dni + " NO está registrado en el servicio RENIEC ni en la clínica.");
        }
    }

    private void verificarCuentaApp(String dni) {
        FirebaseDatabase.getInstance().getReference("pacientes").child(dni)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    tvCuentaEstado.setText("• App Móvil: ✅ Cuenta Activada");
                } else {
                    tvCuentaEstado.setText("• App Móvil: ⚠️ Pendiente de registro por el paciente");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
}
