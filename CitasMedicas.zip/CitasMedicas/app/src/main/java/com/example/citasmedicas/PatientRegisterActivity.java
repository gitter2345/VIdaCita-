package com.example.citasmedicas;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.citasmedicas.db.FirebaseCitaManager;
import com.example.citasmedicas.utils.DniValidator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Locale;

public class PatientRegisterActivity extends AppCompatActivity {

    private EditText etDni, etEmail, etPassword, etNombres, etApellidos, etFechaNac;
    private Spinner spGenero;
    private Button btnRegister;
    private ProgressBar pb;
    private FirebaseAuth mAuth;
    private FirebaseCitaManager firebaseManager;
    private boolean isDniAutorizado = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_register);

        mAuth = FirebaseAuth.getInstance();
        firebaseManager = new FirebaseCitaManager();

        etDni = findViewById(R.id.etRegDni);
        etEmail = findViewById(R.id.etRegEmail);
        etPassword = findViewById(R.id.etRegPassword);
        etNombres = findViewById(R.id.etRegNombres);
        etApellidos = findViewById(R.id.etRegApellidos);
        etFechaNac = findViewById(R.id.etRegFechaNac);
        spGenero = findViewById(R.id.spRegGenero);
        btnRegister = findViewById(R.id.btnConfirmarRegistro);
        pb = findViewById(R.id.pbRegister);

        configurarSpinnerGenero();

        etFechaNac.setOnClickListener(v -> mostrarDatePicker());

        btnRegister.setOnClickListener(v -> realizarRegistro());

        etDni.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 8) {
                    verificarDniEnPadron(s.toString());
                } else {
                    isDniAutorizado = false;
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void mostrarDatePicker() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.YEAR, -25); // Por defecto hace 25 años
        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    String fecha = String.format(Locale.getDefault(), "%02d/%02d/%d", dayOfMonth, month + 1, year);
                    etFechaNac.setText(fecha);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        );
        dialog.show();
    }

    private void configurarSpinnerGenero() {
        if (spGenero == null) return;
        String[] generos = {"Masculino", "Femenino", "Otro"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, generos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spGenero.setAdapter(adapter);
    }

    private void verificarDniEnPadron(String dni) {
        com.example.citasmedicas.utils.ReniecApiService.consultarDniReniec(dni, new com.example.citasmedicas.utils.ReniecApiService.ReniecCallback() {
            @Override
            public void onSuccess(com.example.citasmedicas.model.ReniecResultado resultado) {
                if (resultado != null && resultado.exito) {
                    isDniAutorizado = true;
                    Toast.makeText(PatientRegisterActivity.this, "¡Hola " + resultado.nombres + "! DNI verificado en RENIEC.", Toast.LENGTH_SHORT).show();
                    bloquearCampoTexto(etNombres, resultado.nombres);
                    bloquearCampoTexto(etApellidos, resultado.getApellidos());
                } else {
                    isDniAutorizado = false;
                    Toast.makeText(PatientRegisterActivity.this, "DNI no registrado en RENIEC ni en el padrón.", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onError(String mensajeError) {
                isDniAutorizado = false;
                Toast.makeText(PatientRegisterActivity.this, "DNI no autorizado por la clínica", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void bloquearCampoTexto(EditText editText, String texto) {
        if (editText != null) {
            if (texto != null) {
                editText.setText(texto);
            }
            editText.setFocusable(false);
            editText.setFocusableInTouchMode(false);
            editText.setClickable(false);
            editText.setTextColor(android.graphics.Color.parseColor("#0F172A"));
        }
    }

    private void realizarRegistro() {
        String dni = etDni.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        final String pass = etPassword.getText().toString().trim();
        String nom = etNombres.getText().toString().trim();
        String ape = etApellidos.getText().toString().trim();
        String fechaNac = etFechaNac.getText().toString().trim();
        String genero = (spGenero != null && spGenero.getSelectedItem() != null) 
                ? spGenero.getSelectedItem().toString() : "Masculino";

        if (!isDniAutorizado) {
            Toast.makeText(this, "Su DNI no está autorizado. Acuda a recepción.", Toast.LENGTH_LONG).show();
            return;
        }

        if (email.isEmpty() || pass.isEmpty() || nom.isEmpty() || ape.isEmpty() || fechaNac.isEmpty()) {
            Toast.makeText(this, "Complete todos los campos, incluyendo Fecha de Nacimiento", Toast.LENGTH_SHORT).show();
            return;
        }

        int edadCalculada = DniValidator.calcularEdad(fechaNac);

        btnRegister.setEnabled(false);
        pb.setVisibility(View.VISIBLE);

        mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(task -> {
            if (task.isSuccessful() && mAuth.getCurrentUser() != null) {
                String uid = mAuth.getCurrentUser().getUid();
                
                DatabaseReference pRef = FirebaseDatabase.getInstance().getReference("pacientes").child(dni);
                pRef.child("username").setValue(dni);
                pRef.child("email").setValue(email);
                pRef.child("nombres").setValue(nom);
                pRef.child("apellidos").setValue(ape);
                pRef.child("fechaNacimiento").setValue(fechaNac);
                pRef.child("edad").setValue(edadCalculada);
                pRef.child("genero").setValue(genero);
                pRef.child("rol").setValue("Paciente");
                pRef.child("uid").setValue(uid);

                Toast.makeText(this, "¡Cuenta activada! Edad calculada: " + edadCalculada + " años.", Toast.LENGTH_LONG).show();
                finish();
            } else {
                btnRegister.setEnabled(true);
                pb.setVisibility(View.GONE);
                String errorMsg = (task.getException() != null) ? task.getException().getMessage() : "Error en el registro";
                Toast.makeText(this, "Error: " + errorMsg, Toast.LENGTH_LONG).show();
            }
        });
    }
}
