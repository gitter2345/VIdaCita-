package com.example.citasmedicas.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "medicos")
public class Medico {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String nombre;
    public String especialidad;

    public Medico(String nombre, String especialidad) {
        this.nombre = nombre;
        this.especialidad = especialidad;
    }
}
