package com.example.citasmedicas.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.citasmedicas.R;
import com.example.citasmedicas.model.ReporteEspecialidad;

import java.util.ArrayList;
import java.util.List;

public class ReporteAdapter extends RecyclerView.Adapter<ReporteAdapter.ReporteViewHolder> {

    private List<ReporteEspecialidad> reportes = new ArrayList<>();
    private int maxCitas = 1;

    public void setReportes(List<ReporteEspecialidad> reportes) {
        this.reportes = reportes;
        // Calcular el máximo para que la barra de progreso sea relativa
        this.maxCitas = 0;
        for (ReporteEspecialidad r : reportes) {
            if (r.totalCitas > this.maxCitas) {
                this.maxCitas = r.totalCitas;
            }
        }
        if (this.maxCitas == 0) this.maxCitas = 1;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ReporteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_reporte_especialidad, parent, false);
        return new ReporteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReporteViewHolder holder, int position) {
        ReporteEspecialidad current = reportes.get(position);
        holder.tvEspecialidad.setText(current.especialidad);
        holder.tvTotal.setText(current.totalCitas + " citas");
        
        // Calcular porcentaje relativo al máximo
        int progress = (current.totalCitas * 100) / maxCitas;
        holder.pbDemanda.setProgress(progress);
    }

    @Override
    public int getItemCount() {
        return reportes.size();
    }

    static class ReporteViewHolder extends RecyclerView.ViewHolder {
        TextView tvEspecialidad, tvTotal;
        ProgressBar pbDemanda;

        public ReporteViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEspecialidad = itemView.findViewById(R.id.tvEspecialidadNombre);
            tvTotal = itemView.findViewById(R.id.tvTotalCitas);
            pbDemanda = itemView.findViewById(R.id.pbDemanda);
        }
    }
}
