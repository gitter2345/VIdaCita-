package com.example.citasmedicas;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.citasmedicas.adapter.CitaAdapter;
import com.example.citasmedicas.db.FirebaseCitaManager;
import com.example.citasmedicas.model.Cita;
import com.example.citasmedicas.utils.NotificationHelper;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText etDniBusqueda;
    private TextView tvSinCitas;
    private RecyclerView rvCitas;
    private View btnNotificaciones;
    private View badgeNotificacion;
    private ChipGroup chipGroupPaciente;
    private CitaAdapter adapter;
    private FirebaseCitaManager firebaseManager;
    private LiveData<List<Cita>> currentCitasLiveData;

    private String loggedPatientDni;
    private final Map<String, String> estadosAnteriores = new HashMap<>();
    private final List<String> historialNotificaciones = new ArrayList<>();
    private List<Cita> listaCitasPacienteCompleta = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        firebaseManager = new FirebaseCitaManager();
        loggedPatientDni = getIntent().getStringExtra("PATIENT_DNI");

        etDniBusqueda = findViewById(R.id.etDniBusqueda);
        tvSinCitas = findViewById(R.id.tvSinCitas);
        Button btnBuscar = findViewById(R.id.btnBuscar);
        rvCitas = findViewById(R.id.rvCitas);
        btnNotificaciones = findViewById(R.id.btnNotificaciones);
        badgeNotificacion = findViewById(R.id.badgeNotificacion);
        chipGroupPaciente = findViewById(R.id.chipGroupPaciente);
        View btnLogout = findViewById(R.id.btnLogout);
        ExtendedFloatingActionButton fabAdd = findViewById(R.id.fabAddCita);

        pedirPermisoNotificaciones();

        adapter = new CitaAdapter();
        adapter.setUserRole("Paciente");
        rvCitas.setLayoutManager(new LinearLayoutManager(this));
        rvCitas.setAdapter(adapter);

        if (chipGroupPaciente != null) {
            chipGroupPaciente.setOnCheckedStateChangeListener((group, checkedIds) -> aplicarFiltroPestanas());
        }

        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> confirmarCerrarSesion());
        }

        if (loggedPatientDni != null && !loggedPatientDni.isEmpty()) {
            View layoutBusqueda = findViewById(R.id.layoutBusqueda);
            if (layoutBusqueda != null) {
                layoutBusqueda.setVisibility(View.GONE);
            }
            etDniBusqueda.setText(loggedPatientDni);
            buscarCitas();
        }

        btnBuscar.setOnClickListener(v -> buscarCitas());

        if (btnNotificaciones != null) {
            btnNotificaciones.setOnClickListener(v -> abrirCentroNotificaciones());
        }

        fabAdd.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, ProgramarCitaActivity.class);
            i.putExtra("PATIENT_DNI", loggedPatientDni);
            startActivity(i);
        });

        adapter.setOnCitaClickListener(new CitaAdapter.OnCitaClickListener() {
            @Override
            public void onCancelClick(Cita cita) {
                firebaseManager.actualizarEstadoCita(cita, "Cancelada");
                Toast.makeText(MainActivity.this, "Cita cancelada", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onReprogramClick(Cita cita) {
                Intent i = new Intent(MainActivity.this, ProgramarCitaActivity.class);
                i.putExtra("PATIENT_DNI", loggedPatientDni);
                i.putExtra("EDIT_CITA_ID", cita.id);
                i.putExtra("EDIT_CITA_ESPECIALIDAD", cita.especialidad);
                i.putExtra("EDIT_CITA_MEDICO", cita.nombreMedico);
                i.putExtra("EDIT_CITA_FECHA", cita.fecha);
                i.putExtra("EDIT_CITA_HORA", cita.hora);
                startActivity(i);
            }

            @Override public void onAcceptClick(Cita cita) {}
            @Override public void onRejectClick(Cita cita) {}
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void pedirPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) 
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, 
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
    }

    private void abrirCentroNotificaciones() {
        if (badgeNotificacion != null) {
            badgeNotificacion.setVisibility(View.GONE);
        }

        if (historialNotificaciones.isEmpty()) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle("🔔 Centro de Notificaciones")
                    .setMessage("No tienes notificaciones recientes. Aquí recibirás avisos cuando tus citas sean aprobadas, reprogramadas o canceladas.")
                    .setPositiveButton("Entendido", null)
                    .show();
            return;
        }

        ArrayAdapter<String> notifAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                historialNotificaciones
        );

        ListView listView = new ListView(this);
        listView.setAdapter(notifAdapter);
        listView.setPadding(32, 16, 32, 16);

        new MaterialAlertDialogBuilder(this)
                .setTitle("🔔 Notificaciones VIDACITA")
                .setView(listView)
                .setPositiveButton("Cerrar", null)
                .setNeutralButton("Limpiar Historial", (dialog, which) -> {
                    historialNotificaciones.clear();
                    Toast.makeText(MainActivity.this, "Historial de notificaciones limpiado", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void confirmarCerrarSesion() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("🚪 Cerrar Sesión")
                .setMessage("¿Estás seguro de que deseas salir de tu cuenta VIDACITA?")
                .setPositiveButton("Sí, Salir", (dialog, which) -> {
                    com.google.firebase.auth.FirebaseAuth.getInstance().signOut();
                    Toast.makeText(MainActivity.this, "Sesión cerrada correctamente", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(MainActivity.this, RoleSelectionActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                    finish();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void registrarNotificacionEnHistorial(Cita c) {
        String horaActual = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        String msg;

        if ("Programada".equalsIgnoreCase(c.estado)) {
            msg = "🟢 [Aprobada - " + horaActual + "]\nTu cita de " + c.especialidad + " con " + c.nombreMedico + " para el " + c.fecha + " " + c.hora + " fue confirmada.";
        } else if ("Cancelada".equalsIgnoreCase(c.estado)) {
            msg = "🔴 [Cancelada - " + horaActual + "]\nTu cita de " + c.especialidad + " con " + c.nombreMedico + " ha sido cancelada.";
        } else if ("Pendiente de Aprobación".equalsIgnoreCase(c.estado)) {
            msg = "🟡 [Reprogramación - " + horaActual + "]\nSolicitud de cita para el " + c.fecha + " " + c.hora + " enviada para aprobación.";
        } else {
            msg = "📋 [" + c.estado + " - " + horaActual + "]\nCita de " + c.especialidad + " con " + c.nombreMedico + " cambio de estado.";
        }

        historialNotificaciones.add(0, msg);
        if (badgeNotificacion != null) {
            badgeNotificacion.setVisibility(View.VISIBLE);
        }
    }

    private void buscarCitas() {
        String dni = etDniBusqueda.getText().toString().trim();
        if (dni.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese un DNI", Toast.LENGTH_SHORT).show();
            return;
        }

        if (currentCitasLiveData != null) {
            currentCitasLiveData.removeObservers(this);
        }

        currentCitasLiveData = firebaseManager.getCitasPorDni(dni);
        currentCitasLiveData.observe(this, citas -> {
            this.listaCitasPacienteCompleta = (citas != null) ? citas : new ArrayList<>();
            aplicarFiltroPestanas();

            if (citas != null) {
                for (Cita c : citas) {
                    if (c.id != null) {
                        String estadoAnterior = estadosAnteriores.get(c.id);
                        if (estadoAnterior != null && !estadoAnterior.equalsIgnoreCase(c.estado)) {
                            NotificationHelper.mostrarNotificacionCambioEstado(MainActivity.this, c, estadoAnterior);
                            registrarNotificacionEnHistorial(c);
                        }
                        estadosAnteriores.put(c.id, c.estado);
                    }
                }
            }
        });
    }

    private void aplicarFiltroPestanas() {
        if (listaCitasPacienteCompleta == null) return;

        List<Cita> filtradas = new ArrayList<>();
        int selectedChipId = (chipGroupPaciente != null) ? chipGroupPaciente.getCheckedChipId() : -1;

        for (Cita c : listaCitasPacienteCompleta) {
            if (c == null) continue;

            if (selectedChipId == R.id.chipProximas) {
                // Próximas Citas (Programadas o Pendientes de Aprobación)
                if (!"Cancelada".equalsIgnoreCase(c.estado)) {
                    filtradas.add(c);
                }
            } else if (selectedChipId == R.id.chipHistorial) {
                // Historial (Canceladas o Atendidas)
                if ("Cancelada".equalsIgnoreCase(c.estado)) {
                    filtradas.add(c);
                }
            } else {
                // Todas
                filtradas.add(c);
            }
        }

        adapter.setCitas(filtradas);

        if (tvSinCitas != null) {
            if (filtradas.isEmpty()) {
                tvSinCitas.setVisibility(View.VISIBLE);
                if (selectedChipId == R.id.chipProximas) {
                    tvSinCitas.setText("🟢 No tienes citas próximas programadas.\nPresiona 'Nueva Cita' para agendar una.");
                } else if (selectedChipId == R.id.chipHistorial) {
                    tvSinCitas.setText("🕒 No tienes citas canceladas o pasadas en tu historial.");
                } else {
                    tvSinCitas.setText("📋 No tienes citas registradas actualmente.");
                }
            } else {
                tvSinCitas.setVisibility(View.GONE);
            }
        }
    }
}
