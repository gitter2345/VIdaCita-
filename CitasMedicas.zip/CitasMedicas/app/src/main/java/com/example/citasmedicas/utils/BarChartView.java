package com.example.citasmedicas.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class BarChartView extends View {

    public static class BarItem {
        public String label;
        public float value;
        public int color;

        public BarItem(String label, float value, int color) {
            this.label = label;
            this.value = value;
            this.color = color;
        }
    }

    private List<BarItem> barItems = new ArrayList<>();
    private Paint barPaint;
    private Paint textPaint;
    private Paint labelPaint;
    private Paint gridPaint;
    private RectF rectF;

    public BarChartView(Context context) {
        super(context);
        init();
    }

    public BarChartView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BarChartView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barPaint.setStyle(Paint.Style.FILL);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.parseColor("#003353"));
        textPaint.setTextSize(32f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);

        labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        labelPaint.setColor(Color.parseColor("#475569"));
        labelPaint.setTextSize(26f);
        labelPaint.setTextAlign(Paint.Align.CENTER);

        gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridPaint.setColor(Color.parseColor("#E2E8F0"));
        gridPaint.setStrokeWidth(2f);

        rectF = new RectF();
    }

    public void setBarData(List<BarItem> items) {
        this.barItems = items;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (barItems == null || barItems.isEmpty()) return;

        float width = getWidth();
        float height = getHeight();

        float paddingLeft = 40f;
        float paddingRight = 40f;
        float paddingTop = 50f;
        float paddingBottom = 80f;

        float chartWidth = width - paddingLeft - paddingRight;
        float chartHeight = height - paddingTop - paddingBottom;

        // Draw baseline grid
        canvas.drawLine(paddingLeft, height - paddingBottom, width - paddingRight, height - paddingBottom, gridPaint);

        float maxValue = 1f;
        for (BarItem item : barItems) {
            if (item.value > maxValue) {
                maxValue = item.value;
            }
        }

        int count = barItems.size();
        float barGroupWidth = chartWidth / count;
        float barWidth = Math.min(barGroupWidth * 0.55f, 90f);

        for (int i = 0; i < count; i++) {
            BarItem item = barItems.get(i);

            float centerX = paddingLeft + (i * barGroupWidth) + (barGroupWidth / 2f);
            float left = centerX - (barWidth / 2f);
            float right = centerX + (barWidth / 2f);

            float barHeight = (item.value / maxValue) * chartHeight;
            float top = (height - paddingBottom) - barHeight;
            float bottom = height - paddingBottom;

            // Draw Bar
            barPaint.setColor(item.color);
            rectF.set(left, top, right, bottom);
            canvas.drawRoundRect(rectF, 16f, 16f, barPaint);

            // Draw Value on Top
            canvas.drawText(String.valueOf((int) item.value), centerX, top - 12f, textPaint);

            // Draw Label Below
            String shortLabel = item.label;
            if (shortLabel.length() > 9) {
                shortLabel = shortLabel.substring(0, 7) + "..";
            }
            canvas.drawText(shortLabel, centerX, height - paddingBottom + 45f, labelPaint);
        }
    }
}
