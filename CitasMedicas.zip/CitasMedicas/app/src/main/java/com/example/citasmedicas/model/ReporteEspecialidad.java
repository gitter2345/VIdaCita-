package com.example.citasmedicas.model;

public class ReporteEspecialidad {
    public String especialidad;
    public int totalCitas;

    public ReporteEspecialidad(String especialidad, int totalCitas) {
        this.especialidad = especialidad;
        this.totalCitas = totalCitas;
    }
}
