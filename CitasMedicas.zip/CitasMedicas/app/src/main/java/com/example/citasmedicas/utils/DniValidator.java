package com.example.citasmedicas.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DniValidator {

    /**
     * Valida un DNI peruano con su dígito verificador.
     * Algoritmo basado en el módulo 11 usado por RENIEC.
     */
    public static boolean validarDni(String dni, String digitoVerificador) {
        if (dni == null || dni.length() != 8 || digitoVerificador == null || digitoVerificador.length() != 1) {
            return false;
        }

        try {
            int[] multiplicadores = {3, 2, 7, 6, 5, 4, 3, 2};
            int suma = 0;

            for (int i = 0; i < 8; i++) {
                int num = Character.getNumericValue(dni.charAt(i));
                suma += num * multiplicadores[i];
            }

            int resto = suma % 11;
            int resultado = 11 - resto;
            if (resultado > 9) resultado -= 10;

            String calculado = String.valueOf(resultado);
            return calculado.equals(digitoVerificador);
            
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Separa de forma inteligente una cadena de Nombre Completo en [Nombres, Apellidos].
     * Maneja correctamente nombres compuestos (ej. "Nancy Paola Rodriguez Sanchez" -> ["Nancy Paola", "Rodriguez Sanchez"]).
     */
    public static String[] separarNombresYApellidos(String nombreCompleto) {
        if (nombreCompleto == null || nombreCompleto.trim().isEmpty()) {
            return new String[]{"", ""};
        }

        String[] palabras = nombreCompleto.trim().split("\\s+");
        if (palabras.length == 1) {
            return new String[]{palabras[0], ""};
        } else if (palabras.length == 2) {
            return new String[]{palabras[0], palabras[1]};
        } else if (palabras.length == 3) {
            return new String[]{palabras[0], palabras[1] + " " + palabras[2]};
        } else if (palabras.length == 4) {
            return new String[]{palabras[0] + " " + palabras[1], palabras[2] + " " + palabras[3]};
        } else {
            StringBuilder nom = new StringBuilder();
            for (int i = 0; i < palabras.length - 2; i++) {
                if (i > 0) nom.append(" ");
                nom.append(palabras[i]);
            }
            String ape = palabras[palabras.length - 2] + " " + palabras[palabras.length - 1];
            return new String[]{nom.toString(), ape};
        }
    }

    /**
     * Calcula la edad exacta de forma dinámica a partir de la Fecha de Nacimiento (DD/MM/AAAA).
     * Se actualiza automáticamente cada año según la fecha actual.
     */
    public static int calcularEdad(String fechaNacimientoStr) {
        if (fechaNacimientoStr == null || fechaNacimientoStr.trim().isEmpty()) return 0;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date birthDate = sdf.parse(fechaNacimientoStr.trim());
            if (birthDate == null) return 0;

            Calendar dob = Calendar.getInstance();
            dob.setTime(birthDate);
            Calendar today = Calendar.getInstance();

            int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
            if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
                age--;
            }
            return Math.max(0, age);
        } catch (Exception e) {
            return 0;
        }
    }
}
