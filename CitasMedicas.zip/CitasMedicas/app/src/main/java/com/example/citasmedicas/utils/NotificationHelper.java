package com.example.citasmedicas.utils;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.citasmedicas.MainActivity;
import com.example.citasmedicas.R;
import com.example.citasmedicas.model.Cita;

public class NotificationHelper {

    private static final String CHANNEL_ID = "citas_status_channel";
    private static final String CHANNEL_NAME = "Actualizaciones de Citas Médicas";

    public static void mostrarNotificacionCambioEstado(Context context, Cita cita, String estadoAnterior) {
        if (context == null || cita == null) return;

        NotificationManager notificationManager = 
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (notificationManager == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }

        // Crear canal de notificación para Android 8.0+ (API 26+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Notificaciones sobre aprobación, reprogramación y estado de citas");
            channel.enableVibration(true);
            notificationManager.createNotificationChannel(channel);
        }

        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra("PATIENT_DNI", cita.dniPaciente);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                (int) System.currentTimeMillis(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String titulo;
        String mensaje;

        if ("Programada".equalsIgnoreCase(cita.estado)) {
            titulo = "🟢 ¡Tu cita ha sido Aprobada!";
            mensaje = "Hola " + cita.nombres + ", tu cita de " + cita.especialidad + " con el " + cita.nombreMedico + " para el " + cita.fecha + " a las " + cita.hora + " fue confirmada.";
        } else if ("Cancelada".equalsIgnoreCase(cita.estado)) {
            titulo = "🔴 Notificación de Cita Cancelada";
            mensaje = "Hola " + cita.nombres + ", la cita de " + cita.especialidad + " con el " + cita.nombreMedico + " ha sido cancelada.";
        } else if ("Pendiente de Aprobación".equalsIgnoreCase(cita.estado)) {
            titulo = "🟡 Solicitud de Reprogramación";
            mensaje = "Tu cita de " + cita.especialidad + " ha sido enviada para fecha " + cita.fecha + " " + cita.hora + " y está pendiente de aprobación.";
        } else {
            titulo = "📋 Estado de Cita Actualizado: " + cita.estado;
            mensaje = "Tu cita de " + cita.especialidad + " con " + cita.nombreMedico + " ha cambiado de estado.";
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_medical_logo)
                .setContentTitle(titulo)
                .setContentText(mensaje)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(mensaje))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setContentIntent(pendingIntent);

        int notificationId = (cita.id != null) ? cita.id.hashCode() : (int) System.currentTimeMillis();
        notificationManager.notify(notificationId, builder.build());
    }
}
