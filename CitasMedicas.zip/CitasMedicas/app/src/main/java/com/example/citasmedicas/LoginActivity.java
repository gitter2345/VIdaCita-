package com.example.citasmedicas;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.citasmedicas.db.FirebaseCitaManager;
import com.example.citasmedicas.model.Usuario;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;
    private ProgressBar pbLoading;
    private FirebaseCitaManager firebaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        firebaseManager = new FirebaseCitaManager();

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        pbLoading = findViewById(R.id.pbLoading);
        TextView tvForgot = findViewById(R.id.tvForgotPasswordAdmin);

        btnLogin.setOnClickListener(v -> intentarLogin());

        if (tvForgot != null) {
            tvForgot.setOnClickListener(v -> mostrarDialogoRecuperarPasswordAdmin());
        }
    }

    private void mostrarDialogoRecuperarPasswordAdmin() {
        final EditText etEmailReset = new EditText(this);
        etEmailReset.setHint("ejemplo@vidacita.com");
        etEmailReset.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        
        String user = etUsername.getText().toString().trim();
        if (!user.isEmpty()) {
            if (user.contains("@")) {
                etEmailReset.setText(user);
            } else {
                etEmailReset.setText(user + "@vidacita.com");
            }
        }

        new MaterialAlertDialogBuilder(this)
                .setTitle("🔑 Recuperar Contraseña Médica")
                .setMessage("Ingresa tu correo institucional registrado para enviarte un enlace de restablecimiento seguro de clave.")
                .setView(etEmailReset)
                .setPositiveButton("Enviar Enlace", (dialog, which) -> {
                    String email = etEmailReset.getText().toString().trim();
                    if (email.isEmpty()) {
                        Toast.makeText(this, "Por favor ingrese un correo válido", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    Toast.makeText(this, "¡Enlace de recuperación enviado a " + email + "! Revisa tu correo.", Toast.LENGTH_LONG).show();
                                } else {
                                    String err = (task.getException() != null) ? task.getException().getMessage() : "Error al enviar correo";
                                    Toast.makeText(this, "Error: " + err, Toast.LENGTH_LONG).show();
                                }
                            });
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void intentarLogin() {
        String user = etUsername.getText().toString().trim();
        String pass = etPassword.getText().toString().trim();

        if (user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Por favor complete todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        btnLogin.setEnabled(false);
        pbLoading.setVisibility(View.VISIBLE);

        firebaseManager.validarUsuario(user, pass, new FirebaseCitaManager.LoginCallback() {
            @Override
            public void onSuccess(Usuario usuario) {
                runOnUiThread(() -> {
                    pbLoading.setVisibility(View.GONE);
                    Toast.makeText(LoginActivity.this, "Bienvenido " + usuario.username, Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(LoginActivity.this, AdminDashboardActivity.class);
                    i.putExtra("USER_ROL", usuario.rol);
                    if (usuario.especialidad != null) {
                        i.putExtra("USER_ESPECIALIDAD", usuario.especialidad);
                    }
                    startActivity(i);
                    finish();
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    btnLogin.setEnabled(true);
                    pbLoading.setVisibility(View.GONE);
                    Toast.makeText(LoginActivity.this, error, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }
}
