package com.example.citasmedicas;

import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.citasmedicas.adapter.ReporteAdapter;
import com.example.citasmedicas.db.FirebaseCitaManager;
import com.example.citasmedicas.model.ReporteEspecialidad;
import com.example.citasmedicas.utils.BarChartView;

import java.util.ArrayList;
import java.util.List;

public class AdminTacticoActivity extends AppCompatActivity {

    private ReporteAdapter adapter;
    private BarChartView barChartDemanda;
    private FirebaseCitaManager firebaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_tactico);

        firebaseManager = new FirebaseCitaManager();
        RecyclerView rvReporte = findViewById(R.id.rvReporteEspecialidades);
        barChartDemanda = findViewById(R.id.barChartDemanda);
        
        adapter = new ReporteAdapter();
        rvReporte.setLayoutManager(new LinearLayoutManager(this));
        rvReporte.setAdapter(adapter);

        cargarReportes();
    }

    private void cargarReportes() {
        firebaseManager.getReporteEspecialidades().observe(this, (List<ReporteEspecialidad> reportes) -> {
            if (reportes == null) return;
            
            adapter.setReportes(reportes);

            if (barChartDemanda != null) {
                List<BarChartView.BarItem> barItems = new ArrayList<>();
                int[] barColors = {
                    Color.parseColor("#004B76"),
                    Color.parseColor("#2E7D32"),
                    Color.parseColor("#006874"),
                    Color.parseColor("#B45309"),
                    Color.parseColor("#6B21A8"),
                    Color.parseColor("#0288D1")
                };
                int idx = 0;
                for (ReporteEspecialidad r : reportes) {
                    int color = barColors[idx % barColors.length];
                    barItems.add(new BarChartView.BarItem(r.especialidad, r.totalCitas, color));
                    idx++;
                }
                barChartDemanda.setBarData(barItems);
            }
        });
    }
}
