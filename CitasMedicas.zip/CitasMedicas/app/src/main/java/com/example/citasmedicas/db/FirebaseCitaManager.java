package com.example.citasmedicas.db;

import com.example.citasmedicas.model.Cita;
import com.example.citasmedicas.model.ReporteEspecialidad;
import com.example.citasmedicas.model.Usuario;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

public class FirebaseCitaManager {

    private final DatabaseReference mDatabase;

    public FirebaseCitaManager() {
        mDatabase = FirebaseDatabase.getInstance().getReference("citas");
        inicializarJefesDeAreaDefault();
    }

    public void registrarCita(Cita cita) {
        String key = mDatabase.push().getKey();
        if (key != null) {
            cita.id = key;
            mDatabase.child(key).setValue(cita);
        }
    }

    public void actualizarEstadoCita(Cita cita, String nuevoEstado) {
        if (cita.id != null) {
            mDatabase.child(cita.id).child("estado").setValue(nuevoEstado);
        }
    }

    public void actualizarCita(Cita cita) {
        if (cita.id != null) {
            mDatabase.child(cita.id).setValue(cita);
        }
    }

    public LiveData<List<Cita>> getCitasPorDni(String dni) {
        MutableLiveData<List<Cita>> citasLiveData = new MutableLiveData<>();
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Cita> list = new ArrayList<>();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Cita c = postSnapshot.getValue(Cita.class);
                    if (c != null && c.dniPaciente != null && c.dniPaciente.trim().equals(dni.trim())) {
                        list.add(c);
                    }
                }
                citasLiveData.setValue(list);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        return citasLiveData;
    }

    public LiveData<List<Cita>> getTodasLasCitas() {
        MutableLiveData<List<Cita>> citasLiveData = new MutableLiveData<>();
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Cita> list = new ArrayList<>();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    list.add(postSnapshot.getValue(Cita.class));
                }
                citasLiveData.setValue(list);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        return citasLiveData;
    }

    public LiveData<List<Cita>> getCitasPorEspecialidad(String especialidad) {
        MutableLiveData<List<Cita>> citasLiveData = new MutableLiveData<>();
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Cita> list = new ArrayList<>();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Cita c = postSnapshot.getValue(Cita.class);
                    if (c != null && c.especialidad != null && c.especialidad.equalsIgnoreCase(especialidad)) {
                        list.add(c);
                    }
                }
                citasLiveData.setValue(list);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        return citasLiveData;
    }

    public LiveData<List<ReporteEspecialidad>> getReporteEspecialidades() {
        MutableLiveData<List<ReporteEspecialidad>> reporteLiveData = new MutableLiveData<>();
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map<String, Integer> counts = new HashMap<>();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Cita cita = postSnapshot.getValue(Cita.class);
                    if (cita != null && cita.especialidad != null) {
                        counts.put(cita.especialidad, counts.getOrDefault(cita.especialidad, 0) + 1);
                    }
                }
                List<ReporteEspecialidad> list = new ArrayList<>();
                for (Map.Entry<String, Integer> entry : counts.entrySet()) {
                    list.add(new ReporteEspecialidad(entry.getKey(), entry.getValue()));
                }
                reporteLiveData.setValue(list);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        return reporteLiveData;
    }

    public LiveData<Map<String, Integer>> getKPIsDetallados(String especialidad) {
        MutableLiveData<Map<String, Integer>> kpisLiveData = new MutableLiveData<>();
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int total = 0;
                int programadas = 0;
                int pendientes = 0;
                int canceladas = 0;

                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Cita cita = postSnapshot.getValue(Cita.class);
                    if (cita != null) {
                        if (especialidad != null && !especialidad.isEmpty() && 
                            (cita.especialidad == null || !cita.especialidad.equalsIgnoreCase(especialidad))) {
                            continue;
                        }
                        total++;
                        if ("Cancelada".equalsIgnoreCase(cita.estado)) {
                            canceladas++;
                        } else if ("Pendiente de Aprobación".equalsIgnoreCase(cita.estado)) {
                            pendientes++;
                        } else {
                            programadas++;
                        }
                    }
                }
                Map<String, Integer> res = new HashMap<>();
                res.put("total", total);
                res.put("programadas", programadas);
                res.put("pendientes", pendientes);
                res.put("canceladas", canceladas);
                kpisLiveData.setValue(res);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
        return kpisLiveData;
    }

    public LiveData<Map<String, Integer>> getKPIs() {
        return getKPIsDetallados(null);
    }

    public LiveData<Map<String, Integer>> getKPIsPorEspecialidad(String especialidad) {
        return getKPIsDetallados(especialidad);
    }

    public LiveData<List<String>> getEspecialidades() {
        MutableLiveData<List<String>> liveData = new MutableLiveData<>();
        FirebaseDatabase.getInstance().getReference("especialidades")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> list = new ArrayList<>();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    list.add(postSnapshot.getKey());
                }
                liveData.setValue(list);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
        return liveData;
    }

    public LiveData<List<String>> getMedicosPorEspecialidad(String especialidad) {
        MutableLiveData<List<String>> liveData = new MutableLiveData<>();
        FirebaseDatabase.getInstance().getReference("especialidades").child(especialidad)
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> list = new ArrayList<>();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    list.add(postSnapshot.getValue(String.class));
                }
                liveData.setValue(list);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
        return liveData;
    }

    public void registrarEnPadron(String dni, String nombreCompleto) {
        FirebaseDatabase.getInstance().getReference("padron_oficial").child(dni).setValue(nombreCompleto);
    }

    public void consultarPadron(String dni, ValueEventListener listener) {
        FirebaseDatabase.getInstance().getReference("padron_oficial").child(dni).addListenerForSingleValueEvent(listener);
    }

    public void guardarHorarioMedico(com.example.citasmedicas.model.HorarioMedico horario) {
        if (horario != null && horario.nombreMedico != null) {
            String key = horario.nombreMedico.replace(".", "").replace(" ", "_");
            FirebaseDatabase.getInstance().getReference("horarios_medicos")
                    .child(key)
                    .setValue(horario);
        }
    }

    public void consultarHorarioMedico(String nombreMedico, ValueEventListener listener) {
        if (nombreMedico != null) {
            String key = nombreMedico.replace(".", "").replace(" ", "_");
            FirebaseDatabase.getInstance().getReference("horarios_medicos")
                    .child(key)
                    .addListenerForSingleValueEvent(listener);
        }
    }

    public interface AvailabilityCallback {
        void onResult(boolean isAvailable);
    }

    public void verificarDisponibilidad(String nombreMedico, String fecha, String hora, AvailabilityCallback callback) {
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean available = true;
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Cita cita = postSnapshot.getValue(Cita.class);
                    if (cita != null && 
                        cita.nombreMedico.equals(nombreMedico) && 
                        cita.fecha.equals(fecha) && 
                        cita.hora.equals(hora) &&
                        !"Cancelada".equals(cita.estado)) {
                        available = false;
                        break;
                    }
                }
                callback.onResult(available);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onResult(false);
            }
        });
    }

    public void registrarJefeDeArea(Usuario jefe) {
        if (jefe != null && jefe.username != null) {
            jefe.rol = "Jefe de Especialidad";
            String email = jefe.username + "@vidacita.com";
            jefe.email = email;
            FirebaseDatabase.getInstance().getReference("usuarios")
                    .child("jefes_de_area")
                    .child(jefe.username)
                    .setValue(jefe);

            try {
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, "123456");
            } catch (Exception ignored) {}
        }
    }

    public void inicializarJefesDeAreaDefault() {
        try {
            DatabaseReference jefesRef = FirebaseDatabase.getInstance().getReference("usuarios").child("jefes_de_area");
            jefesRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (!snapshot.exists()) {
                        registrarJefeDeArea(new Usuario("jefe_medicina", "jefe_medicina@vidacita.com", "Jefe de Especialidad", "Medicina General"));
                        registrarJefeDeArea(new Usuario("jefe_pediatria", "jefe_pediatria@vidacita.com", "Jefe de Especialidad", "Pediatría"));
                        registrarJefeDeArea(new Usuario("jefe_cardiologia", "jefe_cardiologia@vidacita.com", "Jefe de Especialidad", "Cardiología"));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {}
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface LoginCallback {
        void onSuccess(Usuario usuario);
        void onError(String error);
    }

    public void validarUsuario(String username, String password, LoginCallback callback) {
        String email = username.contains("@") ? username : username + "@vidacita.com";

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        cargarPerfilUsuarioCentral(username, callback);
                    } else {
                        // Fallback: Si el usuario demo aún no existía en Firebase Auth, intentar registrarlo en Auth
                        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                                .addOnCompleteListener(createTask -> {
                                    if (createTask.isSuccessful()) {
                                        cargarPerfilUsuarioCentral(username, callback);
                                    } else {
                                        cargarPerfilUsuarioCentral(username, callback);
                                    }
                                });
                    }
                });
    }

    private void cargarPerfilUsuarioCentral(String username, LoginCallback callback) {
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("usuarios");

        usersRef.child(username).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Usuario user = snapshot.getValue(Usuario.class);
                if (user != null) {
                    callback.onSuccess(user);
                } else {
                    usersRef.child("jefes_de_area").child(username).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot jefeSnapshot) {
                            Usuario jefeUser = jefeSnapshot.getValue(Usuario.class);
                            if (jefeUser != null) {
                                callback.onSuccess(jefeUser);
                            } else {
                                usersRef.child("doctores").child(username).addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot docSnapshot) {
                                        Usuario docUser = docSnapshot.getValue(Usuario.class);
                                        if (docUser != null) {
                                            callback.onSuccess(docUser);
                                        } else {
                                            callback.onError("Usuario o contraseña incorrectos");
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                        callback.onError("Error de conexión");
                                    }
                                });
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            callback.onError("Error de conexión");
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onError("Error de servidor");
            }
        });
    }
}
