package com.example.citasmedicas.model;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class HorarioMedico {
    public String nombreMedico;
    public String especialidad;
    public String diasAtencion;
    public String horaInicio;
    public String horaFin;
    public String estado; // "Disponible", "En Descanso"

    public HorarioMedico() {
        // Requerido por Firebase
    }

    public HorarioMedico(String nombreMedico, String especialidad, String diasAtencion, String horaInicio, String horaFin, String estado) {
        this.nombreMedico = nombreMedico;
        this.especialidad = especialidad;
        this.diasAtencion = diasAtencion;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.estado = estado;
    }
}
