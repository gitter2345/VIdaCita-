package com.example.citasmedicas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.citasmedicas.adapter.CitaAdapter;
import com.example.citasmedicas.db.FirebaseCitaManager;
import com.example.citasmedicas.model.Cita;
import com.google.android.material.chip.ChipGroup;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AdminOperacionalActivity extends AppCompatActivity {

    private CitaAdapter adapter;
    private FirebaseCitaManager firebaseManager;
    private String userEspecialidad;
    private ChipGroup chipGroupFiltro;
    private TextView tvSinCitasOperacional;

    private List<Cita> listaCitasCompleta = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_operacional);

        firebaseManager = new FirebaseCitaManager();
        RecyclerView rvTotalCitas = findViewById(R.id.rvTotalCitas);
        chipGroupFiltro = findViewById(R.id.chipGroupFiltro);
        tvSinCitasOperacional = findViewById(R.id.tvSinCitasOperacional);
        
        String rol = getIntent().getStringExtra("USER_ROL");
        userEspecialidad = getIntent().getStringExtra("USER_ESPECIALIDAD");

        adapter = new CitaAdapter();
        adapter.setUserRole(rol != null ? rol : "Doctor"); 
        rvTotalCitas.setLayoutManager(new LinearLayoutManager(this));
        rvTotalCitas.setAdapter(adapter);

        if (chipGroupFiltro != null) {
            chipGroupFiltro.setOnCheckedStateChangeListener((group, checkedIds) -> aplicarFiltroActual());
        }

        cargarCitas();

        adapter.setOnCitaClickListener(new CitaAdapter.OnCitaClickListener() {
            @Override
            public void onCancelClick(Cita cita) {
                firebaseManager.actualizarEstadoCita(cita, "Cancelada");
                Toast.makeText(AdminOperacionalActivity.this, "Cita cancelada por administración", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onReprogramClick(Cita cita) {
                Intent i = new Intent(AdminOperacionalActivity.this, ProgramarCitaActivity.class);
                i.putExtra("PATIENT_DNI", cita.dniPaciente);
                i.putExtra("EDIT_CITA_ID", cita.id);
                i.putExtra("EDIT_CITA_FECHA", cita.fecha);
                i.putExtra("EDIT_CITA_HORA", cita.hora);
                startActivity(i);
            }

            @Override
            public void onAcceptClick(Cita cita) {
                firebaseManager.actualizarEstadoCita(cita, "Programada");
                Toast.makeText(AdminOperacionalActivity.this, "Cita aprobada", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onRejectClick(Cita cita) {
                firebaseManager.actualizarEstadoCita(cita, "Cancelada");
                Toast.makeText(AdminOperacionalActivity.this, "Cambio de cita rechazado", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cargarCitas() {
        if (userEspecialidad != null && !userEspecialidad.isEmpty()) {
            firebaseManager.getCitasPorEspecialidad(userEspecialidad).observe(this, citas -> {
                this.listaCitasCompleta = (citas != null) ? citas : new ArrayList<>();
                aplicarFiltroActual();
            });
        } else {
            firebaseManager.getTodasLasCitas().observe(this, citas -> {
                this.listaCitasCompleta = (citas != null) ? citas : new ArrayList<>();
                aplicarFiltroActual();
            });
        }
    }

    private void aplicarFiltroActual() {
        if (listaCitasCompleta == null) return;

        List<Cita> filtradas = new ArrayList<>();
        int selectedChipId = (chipGroupFiltro != null) ? chipGroupFiltro.getCheckedChipId() : -1;

        String hoyStr = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());

        for (Cita c : listaCitasCompleta) {
            if (c == null) continue;

            if (selectedChipId == R.id.chipHoy) {
                // Filtro "Citas de Hoy"
                if (c.fecha != null && c.fecha.equalsIgnoreCase(hoyStr)) {
                    filtradas.add(c);
                }
            } else if (selectedChipId == R.id.chipPendientes) {
                // Filtro "Pendientes de Aprobación"
                if (c.estado != null && c.estado.equalsIgnoreCase("Pendiente de Aprobación")) {
                    filtradas.add(c);
                }
            } else {
                // Filtro "Todas las Citas"
                filtradas.add(c);
            }
        }

        adapter.setCitas(filtradas);

        if (tvSinCitasOperacional != null) {
            if (filtradas.isEmpty()) {
                tvSinCitasOperacional.setVisibility(View.VISIBLE);
                if (selectedChipId == R.id.chipHoy) {
                    tvSinCitasOperacional.setText("📅 No hay citas programadas para el día de hoy (" + hoyStr + ").");
                } else if (selectedChipId == R.id.chipPendientes) {
                    tvSinCitasOperacional.setText("🟡 No hay citas pendientes de aprobación actualmente.");
                } else {
                    tvSinCitasOperacional.setText("📋 No se encontraron citas en este momento.");
                }
            } else {
                tvSinCitasOperacional.setVisibility(View.GONE);
            }
        }
    }
}
