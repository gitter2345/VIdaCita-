package com.example.citasmedicas.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
@Entity(tableName = "citas")
public class Cita {
    @PrimaryKey(autoGenerate = true)
    public int idLocal; // ID para Room
    
    public String id; // Firebase push key
    public String dniPaciente;
    public String nombres;
    public String apellidos;
    public String genero;
    public int edad;
    public String nombreMedico;
    public String especialidad;
    public String fecha;
    public String hora;
    public String estado; // "Programada", "Cancelada"

    public Cita() {
        // Constructor vacío requerido para Firebase
    }

    public Cita(String dniPaciente, String nombres, String apellidos, String genero, int edad, 
                String nombreMedico, String especialidad, String fecha, String hora) {
        this.dniPaciente = dniPaciente;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.genero = genero;
        this.edad = edad;
        this.nombreMedico = nombreMedico;
        this.especialidad = especialidad;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = "Programada";
    }
}
