package com.example.citasmedicas.utils;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;

import com.example.citasmedicas.model.ReniecResultado;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ReniecApiService {

    public interface ReniecCallback {
        void onSuccess(ReniecResultado resultado);
        void onError(String mensajeError);
    }

    private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static void consultarDniReniec(String dni, ReniecCallback callback) {
        if (dni == null || dni.trim().length() != 8) {
            callback.onError("El DNI debe contener exactamente 8 dígitos.");
            return;
        }

        final String dniLimpio = dni.trim();

        executor.execute(() -> {
            boolean exitoWeb = false;
            ReniecResultado resultadoWeb = null;

            try {
                // 1. Intentar consulta HTTP REST a API RENIEC Pública
                URL url = new URL("https://dniruc.apisperu.com/api/v1/dni/" + dniLimpio + "?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(3000);

                if (conn.getResponseCode() == 200) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    JSONObject json = new JSONObject(response.toString());
                    String nombres = json.optString("nombres", "");
                    String pat = json.optString("apellidoPaterno", "");
                    String mat = json.optString("apellidoMaterno", "");

                    if (!nombres.isEmpty()) {
                        resultadoWeb = new ReniecResultado(dniLimpio, nombres, pat, mat, true, "API RENIEC Web");
                        exitoWeb = true;
                    }
                }
                conn.disconnect();
            } catch (Exception ignored) {
                exitoWeb = false;
            }

            if (exitoWeb && resultadoWeb != null) {
                final ReniecResultado resFinal = resultadoWeb;
                mainHandler.post(() -> callback.onSuccess(resFinal));
            } else {
                // 2. Respaldo Automático Infallible: Consultar Padrón Oficial Firebase
                consultarPadrónFirebaseFallback(dniLimpio, callback);
            }
        });
    }

    private static void consultarPadrónFirebaseFallback(String dni, ReniecCallback callback) {
        FirebaseDatabase.getInstance().getReference("padron_oficial").child(dni)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String nombreCompleto = snapshot.getValue(String.class);
                    if (nombreCompleto != null) {
                        String[] partes = DniValidator.separarNombresYApellidos(nombreCompleto);
                        String[] apellidosSub = partes[1].split("\\s+", 2);
                        String pat = (apellidosSub.length > 0) ? apellidosSub[0] : "";
                        String mat = (apellidosSub.length > 1) ? apellidosSub[1] : "";

                        ReniecResultado res = new ReniecResultado(dni, partes[0], pat, mat, true, "Padrón RENIEC Oficial");
                        mainHandler.post(() -> callback.onSuccess(res));
                        return;
                    }
                }
                mainHandler.post(() -> callback.onError("El DNI " + dni + " no figura registrado en RENIEC ni en el padrón de la clínica."));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                mainHandler.post(() -> callback.onError("Error de conexión al consultar el servicio RENIEC."));
            }
        });
    }
}
