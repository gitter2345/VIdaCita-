# Plan de Implementación - Nivel 1: Citas Médicas (Operacional)

Implementación de la base transaccional para la gestión de citas médicas: consulta por DNI, programación y cancelación, utilizando Room y Java.

## Cambios Propuestos

### Configuración y Dependencias

#### [MODIFY] [libs.versions.toml](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/gradle/libs.versions.toml)
Añadir las versiones y librerías de Room.

#### [MODIFY] [build.gradle.kts](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/build.gradle.kts)
Aplicar las dependencias de Room y habilitar el procesador de anotaciones.

---

### Modelo de Datos (Room)

#### [NEW] [Cita.java](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/src/main/java/com/example/citasmedicas/model/Cita.java)
Entidad que representa una cita médica.

#### [NEW] [Medico.java](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/src/main/java/com/example/citasmedicas/model/Medico.java)
Entidad para los médicos (para poblar los selectores).

#### [NEW] [AppDatabase.java](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/src/main/java/com/example/citasmedicas/db/AppDatabase.java)
Configuración de la base de datos Room.

#### [NEW] [CitaDao.java](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/src/main/java/com/example/citasmedicas/db/CitaDao.java)
Interfaz para las operaciones de base de datos (CRUD).

---

### Interfaz de Usuario (UI)

#### [MODIFY] [activity_main.xml](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/src/main/res/layout/activity_main.xml)
Diseño de la pantalla principal:
- Campo de texto para DNI.
- Botón de búsqueda.
- Lista (RecyclerView) de citas.
- Botón flotante para "Programar Cita".

#### [NEW] [item_cita.xml](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/src/main/res/layout/item_cita.xml)
Diseño para cada elemento de la lista de citas.

#### [NEW] [ProgramarCitaActivity.java](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/src/main/java/com/example/citasmedicas/ProgramarCitaActivity.java)
Actividad para el formulario de programación de citas.

#### [NEW] [activity_programar_cita.xml](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/src/main/res/layout/activity_programar_cita.xml)
Diseño del formulario de programación.

---

### Lógica de Negocio

#### [MODIFY] [MainActivity.java](file:///C:/Users/Manuel/AndroidStudioProjects/CitasMedicas/app/src/main/java/com/example/citasmedicas/MainActivity.java)
Integración de la búsqueda por DNI y la actualización de la lista.

## Plan de Verificación

### Pruebas Manuales
1.  **Registro**: Programar una cita y verificar que aparezca al buscar por DNI.
2.  **Consulta**: Ingresar un DNI y ver solo las citas asociadas.
3.  **Cancelación**: Tocar el botón de cancelar y verificar que el estado cambie visualmente.
